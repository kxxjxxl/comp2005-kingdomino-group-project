import java.awt.Color;
import java.awt.Dimension;

import javax.swing.*;
import javax.swing.border.MatteBorder;


/*
 * This class represents a Domino object
 * @author Mahek Parmar
 * 
 */
public class Domino extends JButton {
	//all these are the details pertaining to a domino
	protected String leftTerrain;
	protected String rightTerrain;
	protected int number;
	protected int stars;
	protected String frontFileLocation;
	protected String rearFileLocation;
	
	//additional fields to help in gameplay
	protected Boolean chosen;
	protected int ownedBy;
	protected String ownedByName;
	protected Boolean canBePlaced ;
	
	public Domino(int number, int stars, String rearFileLocation, String frontFileLocation, String leftTerrain, String rightTerrain) {
		super();
		this.number = number;
		this.frontFileLocation = frontFileLocation;
		this.rearFileLocation = rearFileLocation;
		this.stars = stars;
		this.leftTerrain = leftTerrain;
		this.rightTerrain = rightTerrain;
		
		
		chosen = false;					//whether the domino is chosen or not
		canBePlaced = false;			//if it can be placed or not
		ownedByName ="";				//the player who selects the domino
		setUp();
	}
	

	/*
	 * This function sets the default image of the Domino - the part which has the domino number
	 */
	public void setUp() {
	
		try {
			//tileFront represents the domino number part
			
			ImageIcon tileFront = new ImageIcon(Domino.class.getResource(frontFileLocation));
		
			this.setIcon(tileFront);
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}
									
	
	/*
	 * This function flips a domino - changes the front image to the rear image
	 */
	public void flip() {
		
		try {
			ImageIcon tileRear = new ImageIcon(Domino.class.getResource((String)rearFileLocation));
			this.setIcon(tileRear);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * Accessor method that provides the Domino's number
	 * @return number, the domino number
	 */
	public int getDominoNumber() {
		return number;
	}
	
	/*
	 * Accessor method that helps identify if a domino is chosen or not
	 * @return !chosen, whether the domino is unchosen or not
	 */
	public Boolean isUnchosen() {
		return (!chosen);
	}
	
	/*
	 * This method sets a Domino to chosen if it was unchosen
	 * @param player, the playernumber of the player who chose this domino
	 * @param playerName, the name of the player who chose this domino
	 */
	public void chosen(int player, String playerName) {
		if (! chosen) {
			chosen = true;
			ownedBy = player;
			ownedByName = playerName;
		}
	}
	
	/*
	 * Accessor method that provides name of the player who owns this domino
	 * @return ownedByName, the name of the player who owns the domino
	 */
	public String getOwnedByName() {
		return ownedByName;
	}
	
	/*
	 * Accessor method that provides the playernumber of the player who owns this domino
	 * @return ownedBy, the number of the player who owns the domino
	 */
	public int getOwnedByNumber() {
		return ownedBy;
	}
				
	/*
	 * Accessor method that helps us identify if a domino can be placed or not
	 * @return canBePlaced, a boolean stating whether the domino can be placed or not
	 */
	public Boolean canBePlaced() {
		return canBePlaced;
	}
	
	/*
	 * This method allows a domino to be placed
	 * 
	 */
	public void allowToBePlaced() {
		canBePlaced = true;			//set to true == allow to be placed
	}
	
	
	/*
	 * This method returns a smaller version of the left half of the domino
	 * @return JButton, the left part of the button
	 */
	public JButton getLeftTerrain() {
		String filename = "" + number + "B-L.jpg";
		ImageIcon leftTerrain = new ImageIcon(Domino.class.getResource(filename));
		JButton leftTerrainButton = new JButton(leftTerrain);
		
		leftTerrainButton.setBorderPainted(false);
		leftTerrainButton.setPreferredSize(new Dimension(40,40));
		return leftTerrainButton;
	}
	
	/*
	 * This method returns a smaller version of the left half of the domino
	 * @return JButton, the left part of the button
	 */
	public JButton getRightTerrain() {
		String filename = "" + number + "B-R.jpg";
		ImageIcon rightTerrain = new ImageIcon(Domino.class.getResource(filename));
		JButton rightTerrainButton = new JButton(rightTerrain);
		
		rightTerrainButton.setBorderPainted(false);
		rightTerrainButton.setPreferredSize(new Dimension(40,40));
		return rightTerrainButton;
	}
	
}
