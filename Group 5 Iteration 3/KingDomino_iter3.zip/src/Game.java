
import java.io.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;
import java.util.*;

import javax.swing.*;
import javax.swing.border.MatteBorder;

/* The Game class conducts the game and allows the game to be played for the said number of players
* @author Mahek Parmar
* 
*/


public class Game implements ActionListener{
	protected int ROUNDS = 12;			//set as constant class variable 
	protected int dominos_remaining = 48;
	protected int numberOfPlayers;
	protected int currentPlayer;
	
	protected int row = 9;
	protected int col = 9;
	
	protected ArrayList<Player> playerList;
	protected ArrayList <Domino> available_dominos;
	protected ArrayList <Domino> roundDominos1;
	protected ArrayList <Domino> roundDominos2;
	protected ArrayList <Integer> placingOrder = new ArrayList<>();
	
	protected BufferedReader reader;
	protected Random randgen = new Random();
	
	protected JFrame frame;
	protected JLabel dominosRemainingNumber;
	protected JPanel roundDominos1Panel;
	protected JPanel roundDominos2Panel;
	protected JLabel gameInfo;
	
	//set of boolean conditions - ensure the smooth coordination btwn different components
	protected Boolean round1PanelIsLocked = false;				//if the first queue is locked
	protected Boolean round2PanelIsLocked = true;				//if the second queue is locked

	protected Boolean removeFromStack = true;				//if true, remove from stack, if false don't
	protected Boolean chooseDomino = false;
	protected Boolean allowToPlaceDomino = false;			//not used atm - implement
	protected Boolean tilesFlipped = false;
	protected Boolean blockPanels = false;
	
	JButton placeRightButton;
	JButton placeLeftButton; 
	
	protected JButton currentHalfDomino;				//the part of the domino currently being placed
	JButton currentLeftTerrain;
	JButton currentRightTerrain;
	protected JPanel chosenDominoPanel;
	
	protected int placingHalf = 0;
	
	
	public Game(ArrayList<Player> playerList, JFrame frame) {
		this.frame = frame;
		this.playerList = playerList;
		available_dominos = new ArrayList<>();
		roundDominos1 = new ArrayList<>();					//dominos in the first line/queue
		roundDominos2 = new ArrayList<>();					//dominos in the second line/queue
		
		numberOfPlayers = playerList.size();
		//only the first player is randominzed, the rest follow in a circular motion
		//this has been done to mimic an actual border game setting
		currentPlayer = randgen.nextInt(numberOfPlayers);
		currentPlayer +=1;				
		chosenDominoPanel = new JPanel();
		
		currentLeftTerrain= new JButton();
		currentRightTerrain = new JButton();
		currentHalfDomino = new JButton();
		
		setUpDominos();
		setUpFrame();
		setUpPlayerBoards();
		
		frame.pack();
	}

	/*
	 * This method retrieves the individual grids of the board and adds action listeners to them
	 */
	public void setUpPlayerBoards() {
		for (Player p: playerList) {
			Board pBoard = p.getPlayerBoard();
			GridBox [][] grids = pBoard.getBoardGrids();
			for (int a=0 ; a<row ; a++) {
				for (int b=0 ; b<col ; b++) {
					grids[a][b].addActionListener(this);
				}
			}
			}
		}

	/*
	 * This function set's up all the Domino's of our game
	 * 
	 */
	public void setUpDominos() {
		//the details pertaining to every domino are stores in the CSV file DominoDetails.csv in resouces.
		
		String file = "C:/Users/HP/Desktop/Java/KingDomino/resources/DominoDetails.csv";
		String line ="";
		//we parse this file and create the corresponding dominos with their respective attributes
				try {
					reader = new BufferedReader(new FileReader(file));
					line = reader.readLine();//get rid of the headers
					while ((line = reader.readLine()) != null) {
						String [] dominoDetails = line.split(",");
						int number = Integer.parseInt(dominoDetails[0]);
						
						int stars = Integer.parseInt(dominoDetails[1]);
						String frontLocation = dominoDetails[2];
						String rearLocation = dominoDetails[3]; 
						String leftTerrain = dominoDetails[4]; 
						String rightTerrain = dominoDetails[5];
						Domino newDomino = new Domino(number, stars, rearLocation, frontLocation, leftTerrain, rightTerrain);
						newDomino.addActionListener(this);
						
						available_dominos.add(newDomino);			//adding all the dominos to the available_dominos arraylist
						
						}
				}
				catch (Exception e){
					System.out.println("exp");
				}
				finally {
					try {
						reader.close();
					} 
					catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
	}

	/*
	 * This method set's up the frame for the game to be played
	 * 
	 */
	public void setUpFrame() {
		//stack to represent a real world domino stack
		JPanel dominoStack = new JPanel();
		
		JLabel dominosRemainingText = new JLabel("Dominos remaining");
		dominosRemainingNumber = new JLabel("" + dominos_remaining); 
		dominosRemainingText.setFont(new Font("Georgia", Font.BOLD, 20));
		dominosRemainingNumber.setFont(new Font("Georgia", Font.BOLD, 50));
		
		dominosRemainingText.setHorizontalAlignment(JLabel.CENTER);			//label shows how many dominos left
		dominosRemainingText.setVerticalAlignment(JLabel.CENTER);
		dominosRemainingNumber.setVerticalAlignment(JLabel.CENTER);
		dominosRemainingNumber.setHorizontalAlignment(JLabel.CENTER);
		
		dominoStack.setBorder(new MatteBorder(2,2,2,2, Color.black));
		dominoStack.add(dominosRemainingText);
		dominoStack.add(dominosRemainingNumber);
		dominoStack.setBounds(600, 20, 220, 150);
		frame.add(dominoStack);
		
		gameInfo = new JLabel("Click 'Begin Round' to start!");
		gameInfo.setBounds(510,740,600,50);
		gameInfo.setFont(new Font("Georgia", Font.BOLD, 30));
		frame.add(gameInfo);
		
		roundDominos1Panel = new JPanel();					//the first line/queue of dominos
		roundDominos1Panel.setBounds (550,400,130,260);
		roundDominos1Panel.setBorder(new MatteBorder(1,1,1,1,Color.black));
		roundDominos1Panel.setLayout(new GridLayout(4,1));
		frame.add(roundDominos1Panel);
		
		roundDominos2Panel = new JPanel();					//the second line/queue of dominos
		roundDominos2Panel.setBounds(750,400,130,260);
		roundDominos2Panel.setBorder(new MatteBorder(1,1,1,1,Color.black));
		roundDominos2Panel.setLayout(new GridLayout(4,1));
		frame.add(roundDominos2Panel);
		
		JButton beginRoundButton = new JButton("Begin Round");
		beginRoundButton.addActionListener(e -> removeDominos());
		beginRoundButton.setBounds(650,180,130,20);
		frame.add(beginRoundButton);
		
		JButton flipAndSortButton = new JButton("Flip + Sort Dominos");
		flipAndSortButton.addActionListener(e -> flipAndSort());
		flipAndSortButton.setBounds(640,700,150,20);
		frame.add(flipAndSortButton);
		
		chosenDominoPanel.setLayout(new GridLayout(1,2));
		chosenDominoPanel.setBounds(675,250,90,43); 
		chosenDominoPanel.setBorder(new MatteBorder(1,1,1,1, Color.black));
		frame.add(chosenDominoPanel);
		
		//buttons to place the left and right part of the domino
		placeLeftButton = new JButton("Place Left Terrain");
		placeLeftButton.setBounds(550,360,150,20);
		placeLeftButton.addActionListener(e -> placeLeftTerrain());
		frame.add(placeLeftButton);
		
		placeRightButton = new JButton("Place Right Terrain");
		placeRightButton.setBounds(720,360,150,20);
		placeRightButton.addActionListener(e -> placeRightTerrain());
		frame.add(placeRightButton);
		
	}
	
	/*
	 * This method removes dominos from the available ones
	 * 
	 */
	public void removeDominos() {
		if (removeFromStack && (dominos_remaining >=4)) {
			
			for (int i = 0 ; i < 4 ; i++) {
				//for the first line/queue
				if (roundDominos1Panel.getComponentCount() <4) {
					int indexToRemove = getRandomDominoNumber();
					Domino tempDomino = available_dominos.get(indexToRemove);
					roundDominos1.add(tempDomino);
					roundDominos1Panel.add(tempDomino);
					available_dominos.remove(indexToRemove);
					dominos_remaining -=1;
				
				}
				//for the second line/queue
				if (roundDominos2Panel.getComponentCount() <4) {
					int indexToRemove = getRandomDominoNumber();
					Domino tempDomino = available_dominos.get(indexToRemove);
					roundDominos2.add(tempDomino);
					roundDominos2Panel.add(tempDomino);
					available_dominos.remove(indexToRemove);
					dominos_remaining -=1;
				}
			}
			dominosRemainingNumber.setText("" +dominos_remaining);
			gameInfo.setText("Tiles for this round. Flip them!");
			removeFromStack = false;				//prevents further removal of dominos from the stack
			
		}
	}

	
	/*
	 * This method handles the actions performed for the grids of the board and for the dominos
	 * @param aevt, the action event
	 * 
	 */
	public void actionPerformed(ActionEvent aevt) {
		Object source = aevt.getSource();
		//if a Domino object is clicked
		if (source instanceof Domino) {
			//blockPanels => is true when a domino is to be placed, when dominos are getting selected it will be false
			//tilesFlipped => when the tiles are sorted and flipped, only clicking dominos resembles functionalities
			if (!blockPanels && tilesFlipped){
					
				if (roundDominos1.contains((Domino)source) && !(round1PanelIsLocked)) {
					//chooseDomino => will be true once tiles have been flipped
					if (source instanceof Domino && chooseDomino) {
						//if the clicked domino is unchosen, make the chosen giving the currentplayer attributes
						if (((Domino) source).isUnchosen()){
							
							((Domino) source).chosen(currentPlayer, playerList.get(currentPlayer-1).getPlayerName());
							//once a domino is chosen, update the current player
							currentPlayer = (currentPlayer % numberOfPlayers)+1;
						}		
					}
					//reselecting a chosen domino will do nothing
					gameInfo.setText("Player " + currentPlayer+ " choose your domino");
					

					// at this point all dominos in round1panel are chosen, now we want to place them
					if (allChosen(roundDominos1)) {
						//player whose chosen domino is top of the queue/line should place it
						//we get this info using getPlacingOrder function
						getPlacingOrder(roundDominos1, roundDominos1Panel);
						currentPlayer = placingOrder.get(0);
						gameInfo.setText("Player " + currentPlayer + " place your Domino");
						if (((Domino)source).getOwnedByNumber() == placingOrder.get(0)) {
							//allow that domino to be placed
							((Domino)source).allowToBePlaced();
						}
					}
					
					if (((Domino)source).canBePlaced()) {
						placingOrder.remove(0);			//remove from placing order
						playerList.get(currentPlayer-1).getPlayerBoard().unblock();		//unblock that players board so dominos can be placed
						//place the domino 
						placeDomino(((Domino)source), roundDominos1Panel, roundDominos1);
												
					}
					
				}				//for the second queue, will be implemented for next iteration (take a turn)
				else {
					if (roundDominos2.contains((Domino)source) && !(round2PanelIsLocked)) {
						if (source instanceof Domino && chooseDomino) {
							if (((Domino) source).isUnchosen()){
								((Domino) source).chosen(currentPlayer, playerList.get(currentPlayer-1).getPlayerName());
								//placeTile((Domino)source);
								currentPlayer = (currentPlayer % numberOfPlayers)+1;
							}
						}
					}
				}
			}
		}
		//the individual grid of the board is clicked when placing a domino
		else if (source instanceof GridBox) {
			//when the placing half is 0 we have several options to place that first part of the domino
			//when the palcing half is 1, we have at most 3 positions to place the second part of the domino,
			//as the second part must be placed together with the first part
			
			if ( allowToPlaceDomino && ((GridBox)source).isAvailable()  && (((GridBox)source).getBoardNumber() == currentPlayer && (placingHalf ==0))){
			
			
				((GridBox)source).add(currentHalfDomino);	
				((GridBox)source).setBorder(null);
					
				//make that individual gridbox not available and occupied so it cannot be selected again	
				((GridBox)source).setNotAvailable();
				((GridBox)source).makeOccupied();
				
				//once the first part of the domino is placed, we need to adjust the neighbours for the 2nd part of the domino to be placed
				adjustNeighbours(((GridBox)source).getXIndex(), ((GridBox)source).getYIndex(), playerList.get(currentPlayer-1).getPlayerBoard());
					
				chosenDominoPanel.remove(currentHalfDomino);			//remove from the panel which displays the domino to place
					
				currentHalfDomino.removeAll();
				currentHalfDomino = null;								
				placingHalf = (placingHalf +1) %2;					//placing half =1, which means we place the second part now
				allowToPlaceDomino = false;
				frame.pack();
					
			}
			//when placing the second part of the domino
			if ( allowToPlaceDomino && ((GridBox)source).isAvailable()  && ((((GridBox)source).getBoardNumber() == currentPlayer) && (placingHalf ==1)) && ((GridBox)source).isAdjacent()){
				
				((GridBox)source).add(currentHalfDomino);
				((GridBox)source).setBorder(null);
				
				//make that individual gridbox not available and occupied so it cannot be selected again
				((GridBox)source).setNotAvailable();
				((GridBox)source).makeOccupied();
				
				//on placing the second part of the tiles, we adjust the neighbours for placing further tiles
				adjustNeighbours(((GridBox)source).getXIndex(), ((GridBox)source).getYIndex(), playerList.get(currentPlayer-1).getPlayerBoard());
				
				chosenDominoPanel.remove(currentHalfDomino);
				
				currentHalfDomino.removeAll();
				currentHalfDomino = null;
				
				playerList.get(currentPlayer-1).getPlayerBoard().block();
				//once both parts of the domino are places, we now block the placing players board
				placingHalf = (placingHalf +1) %2;
				allowToPlaceDomino = false;
				frame.pack();
				
			}
		}
		
	}
	
	
	/*
	 * This function activiates adjacent cells when half a domino is placed on the board
	 * When the first part of the domino is placed, adjacent positons must be activated (top, left, right, bottom)
	 * @param x, the x index of the individual grid on which the half domino was placed
	 * @param y, x, the y index of the individual grid on which the half domino was placed
	 * @param board, the board which was selected 
	 */
	public void adjustNeighbours(int x, int y, Board board) {
		
		GridBox [][] grids = board.getBoardGrids();
		
		//using try and catch to prevent out of bounds scenarios
				try {			
				//if the upper grid is not occupied, make it available and adjacent
					if (!(grids[x-1][y].isOccupied())) {
						grids[x-1][y].setAdjacent(playerList.get(currentPlayer-1).getColor());
						grids[x-1][y].makeAvailable(playerList.get(currentPlayer-1).getColor());
					}

				}
				catch (Exception e) {}
				try {
				//if the left grid is not occupied, make it available and adjacent
					if (!(grids[x][y-1].isOccupied())) {
						grids[x][y-1].setAdjacent(playerList.get(currentPlayer-1).getColor());
						grids[x][y-1].makeAvailable(playerList.get(currentPlayer-1).getColor());
					}
				}
				catch (Exception e) {}
				try {
				//if the right grid is not occupied, make it available and adjacent
					if (!(grids[x+1][y].isOccupied())) {
				
						grids[x+1][y].setAdjacent(playerList.get(currentPlayer-1).getColor());
						grids[x+1][y].makeAvailable(playerList.get(currentPlayer-1).getColor());
					}
				}
				catch (Exception e) {}
				try {
				//if the bottom grid is not occupied, make it available and adjacent
					if (!(grids[x][y+1].isOccupied())) {
				
						grids[x][y+1].setAdjacent(playerList.get(currentPlayer-1).getColor());
						grids[x][y+1].makeAvailable(playerList.get(currentPlayer-1).getColor());
					}
				}
				catch (Exception e) {}	
						
	}

	
	/*
	 * This function takes the topmost domino from the queue, splits it into 2 parts and displays it 
	 * @param d, the Domino to place
	 * @param panel, the JPanel were the domino was 
	 * @param roundDominos, the arraylist storing dominos of that line/queue
	 */
	public void placeDomino(Domino d, JPanel panel, ArrayList<Domino> roundDominos) {
		currentLeftTerrain = d.getLeftTerrain();			//get the left part of the domino
		currentRightTerrain = d.getRightTerrain();			//get the right part of the domino
		chosenDominoPanel.add(currentLeftTerrain);
		chosenDominoPanel.add(currentRightTerrain);
		panel.remove(d);									//remove the domino from the panel where it initially way
		
		//remove from that list that contains all the dominos of that queue
		for (int q=0 ; q<roundDominos.size() ; q++) {
			if (roundDominos.get(q) == d) {
				roundDominos.remove(q);
				break;
			}
		}
		//now that we are placing a domino, block the queues 
		blockPanels = true;
		frame.pack();
		
	}
	
	/*
	 * This method gives the playernumber order in which dominos are to be placed
	 * The player whose domino is top of the queue should place the domino first
	 * @ param queue, the arraylist of dominos of the current fully chosen queue
	 * @ param panel, the panel which contains the chosen dominos
	 * @ return placingOrder, an arrayList defining which player places their domino first
	 */
	public ArrayList<Integer> getPlacingOrder(ArrayList <Domino> queue, JPanel panel) {
		placingOrder = new ArrayList<>();
		
		for (int y = 0 ; y< queue.size() ; y++) {
			placingOrder.add(((Domino) panel.getComponent(y)).getOwnedByNumber());
			
		}
		return placingOrder;
		
	}

	/*
	 * This function takes an arrayList of Domino can checks if all the dominos are chosen or not
	 * @return Boolean, true if all dominos are chosen, else false
	 */
	public Boolean allChosen(ArrayList<Domino> queue) {
		int z = 0;
		for (Domino d: queue) {
			if (!d.isUnchosen()) {
				z++;
			}
		}
		if (z==queue.size()) {
			return true;					//all dominos in the queue are chosen
		}
		else {
			return false;						//all dominos are not chosen
		}
	}
	

	/*
	 * ActionListener method for the placeLeftButton
	 * This method allows the user to be able to place the left part of the domino
	 * 
	 */
	public void placeLeftTerrain() {
		if (blockPanels) {								//when the panels are blocked, this means dominos are being placed
			allowToPlaceDomino = true;					//allows to click the grid of the board
			currentHalfDomino = currentLeftTerrain;				//when we want to place the left part, currentHalfDomino is set to it
			currentLeftTerrain.removeAll();						
			placeLeftButton.setVisible(false);
		}
	}
	
	
	/*
	 * ActionListener method for the placeRightButton
	 * This method allows the user to be able to place the right part of the domino
	 * 
	 */
	public void placeRightTerrain() {
		if (blockPanels) {									//when the panels are blocked, this means dominos are being placed
			allowToPlaceDomino = true;						//allows to click the grid of the board
			currentHalfDomino = currentRightTerrain;			//when we want to place the right part, currentHalfDomino is set to it
			currentRightTerrain.removeAll();
			placeRightButton.setVisible(false);
		}
	}
		
	
	/*
	 * This method flips every domino once it is removed form the stack and placed in the queues
	 */
	public void flipAndSort() {
		//only works once dominos are removed from the stack
		
		if (!(removeFromStack)) {
			
			roundDominos1Panel.removeAll();
			roundDominos2Panel.removeAll();
			//sorts the dominos in each queue using the sortDomino() function
			//sorts into ascending order 
			roundDominos1 = sortDomino(roundDominos1);
			roundDominos2 = sortDomino(roundDominos2);
			//for the first line/queue
			if (roundDominos1.size() >0) {
				for (Domino d: roundDominos1) {
					roundDominos1Panel.add(d);
					d.flip();					//flips side to show the rear side (one with the terrains and stars)
				}
				frame.pack();
				chooseDomino = true;				//now we allow dominos in the queues/lines to be chosen
			}
			//for the second line/queue
			if (roundDominos2.size() >0) {
				for (Domino d: roundDominos2) {
					roundDominos2Panel.add(d);
					d.flip();
				}
				frame.pack();
				chooseDomino = true;						//now we allow dominos in the queues/lines to be chosen
			}
			tilesFlipped = true;
			gameInfo.setText("Player " + currentPlayer + " choose your tile" );
		}
	}
	
	
	/*
	 * A helper method that helps generate a random number from 0 to the number of avialable dominos
	 * @return temp, the random domino number
	 */
	public int getRandomDominoNumber() {
		int temp = randgen.nextInt(available_dominos.size());
		return temp;
		
	}
	
	
	/*
	 * A method that sorts an arraylist of Domino based on their numbers. It sorts them in 
	 * ascending order, smallest domino number to largest
	 * @param queue, an ArrayList of Dominos to be sorted
	 * @return queue, the sorted ArrayList of Dominos
	 */
	public ArrayList<Domino> sortDomino(ArrayList<Domino> queue) {
		if (queue.size() > 0) {
			Collections.sort(queue, new Comparator<Domino>()
					{
						public int compare(Domino d1, Domino d2) {
							return Integer.valueOf(d1.getDominoNumber()).compareTo(d2.getDominoNumber());
						}
					});	
		}
		return queue;
	}
	
	
	

}
