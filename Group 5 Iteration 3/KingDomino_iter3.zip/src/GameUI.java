import java.awt.*;
import javax.swing.*;
import java.util.*;

/*
 * This class represents the main GUI where KingDomino is played
 * @author Mahek Parmar
 * 
 */
public class GameUI {
	protected ArrayList<Player> playerList;
	protected JFrame frame;
	protected Container contentPane;
	
	public GameUI(ArrayList<Player> playerList) {
		//set-up and housekeeping code
		this.playerList = playerList; 
		frame = new JFrame("KingDomino");
		 
		frame.setLayout(null);
		frame.setPreferredSize(new Dimension(1920,830));
		

		contentPane = frame.getContentPane();
		contentPane.setLayout(null);
		
		
		setUpBoard(); 					//internal method call to set up the board
		Game playGame = new Game(playerList, frame);
		frame.setVisible(true);
		frame.setResizable(false); 
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
		
	}
	
	
	/*
	 * This method setups the Board for every player playing the game
	 * 
	 */
	public void setUpBoard() {
		for (Player player: playerList) {
			 
			Board playerBoard = player.getPlayerBoard();			//gets the playerBoard
			
			//here we position the board on the GUI based on which player it is
			if (player.getPlayerID() ==1) {
				playerBoard.setBounds(50,20,360,360);
			}
			else if (player.getPlayerID() == 2) {
				playerBoard.setBounds(1050,20,360,360);
			}
			else if (player.getPlayerID() == 3) {
				playerBoard.setBounds(50,420,360,360);
			}
			else {
				playerBoard.setBounds(1050,420,360,360);
			}
			
			contentPane.add(playerBoard);			
		}
		
		//internal method calls to add the player and display settings on the GUI
		addPlayerSettings();
		addDisplaySettings();	
		}
	
	
	/*
	 * This method deals with adding the player setting functionality to the game frame
	 * It adds a settings buttons which brings up a frame that allows us to select player settings
	 * 
	 */
	public void addPlayerSettings() {
		//the setting icon, put into the button
		
		try {
			ImageIcon settings = new ImageIcon(GameUI.class.getResource("settings.jpg"));
			JButton settingsButton = new JButton(settings);
			settingsButton.addActionListener(e -> showPlayerSettings());
			
			JPanel settingsPanel = new JPanel();
			settingsPanel.setBounds(1450,0,75,75);
			settingsPanel.add(settingsButton);
			
			contentPane.add(settingsPanel);				
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	/*
	 * This method shows/provides the player settings when the user elects to change the player settings
	 * 
	 */
	public void showPlayerSettings() {
		JFrame settingsFrame = new JFrame ("Player Settings");
		settingsFrame.setLayout(null);
		settingsFrame.setPreferredSize(new Dimension(600,500));
		
		
		PlayerDetails playerDetails = new PlayerDetails(playerList, settingsFrame);			//making use of the PlayerDetails class to provde to build the GUI for player settings
		
		//house keeping code
		settingsFrame.pack();
		settingsFrame.setVisible(true);
		settingsFrame.setResizable(false);
	}
	
	/*
	 * This method adds the display settings functionality to the game frame
	 * It adds a display settings button which brinds up a frame containing the various display settings
	 */
	public void addDisplaySettings() {
		JButton displayButton = new JButton("Display Settings");
		displayButton.addActionListener(e -> showDisplaySettings());
		
		JPanel displayButtonPanel = new JPanel();
		displayButtonPanel.add(displayButton);
		displayButtonPanel.setBounds(1430,760,100,70);
		contentPane.add(displayButtonPanel);		
	}
	
	/*
	 * This method provides us the various display settings when the user clicks the display settings button
	 * 
	 */
	public void showDisplaySettings() {
		JFrame displayFrame = new JFrame("Display Settings");
		displayFrame.setLayout(null);
		displayFrame.setPreferredSize(new Dimension(300,250));
		displayFrame.setResizable(false);
		displayFrame.setVisible(true);
		displayFrame.pack();
		
		//adding the different display setting options to the displayFrame
		addDarkMode(displayFrame);
		addBrightMode(displayFrame);
		addDayMode(displayFrame);
		addContrastOptions(displayFrame);
		
	}
	
	/*
	 * This method makes the game frame support the dark mode
	 * @param frame, the display frame where we add this functionality
	 */
	public void addDarkMode(JFrame frame) {
		//creating the label and button for the 'dark mode'
		
		
		try {
			ImageIcon darkImage = new ImageIcon(GameUI.class.getResource("dark.jpg"));
			JButton darkButton = new JButton(darkImage);
			darkButton.addActionListener(e -> makeDark());
			
			JPanel darkPanel = new JPanel();
			
			JLabel darkModeText = new JLabel("Dark Mode");
			darkModeText.setFont(new Font("Georgia" , Font.ITALIC, 10));
			darkModeText.setVerticalAlignment(JLabel.CENTER);
			darkModeText.setHorizontalAlignment(JLabel.CENTER);
			
			darkPanel.setBounds(10,20,70,90);
			darkPanel.add(darkModeText);
			darkPanel.add(darkButton);
			frame.add(darkPanel);			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	/*
	 * This method is invoked when the user selects dark mode. It makes the game frame dark
	 */
	public void makeDark() {
		contentPane.setBackground(Color.BLACK);
	}
	
	/*
	 * This method makes the game frame support the bright mode
	 * @param frame, the display frame where we add this functionality
	 */
	public void addBrightMode(JFrame frame) {
		
		
		try {
			ImageIcon brightImage = new ImageIcon(GameUI.class.getResource("bright.jpg"));
			JButton brightButton = new JButton(brightImage);
			brightButton.addActionListener(e -> makeBright());
			
			JPanel brightPanel = new JPanel();
			
			JLabel brightModeText = new JLabel("Bright Mode");
			brightModeText.setFont(new Font("Georgia" , Font.ITALIC, 10));
			brightModeText.setVerticalAlignment(JLabel.CENTER);
			brightModeText.setHorizontalAlignment(JLabel.CENTER);
			
			brightPanel.setBounds(100,20,70,90);
			brightPanel.add(brightModeText);
			brightPanel.add(brightButton);
			frame.add(brightPanel);	
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	/*
	 * This method is invoked when the user selects bright mode. It makes the game frame bright
	 */
	public void makeBright() {
		contentPane.setBackground(Color.WHITE);
	}
	
	
	
	/*
	 * This method makes the game frame support the day mode
	 * @param frame, the display frame where we add this functionality
	 */
	public void addDayMode(JFrame frame) {
		
		
		try {
			ImageIcon dayImage = new ImageIcon(GameUI.class.getResource("day.jpg"));
			JButton dayButton = new JButton(dayImage);
			dayButton.addActionListener(e -> makeDay());
			
			JPanel dayPanel = new JPanel();
			
			JLabel dayModeText = new JLabel("Day Mode");
			dayModeText.setFont(new Font("Georgia" , Font.ITALIC, 10));
			dayModeText.setVerticalAlignment(JLabel.CENTER);
			dayModeText.setHorizontalAlignment(JLabel.CENTER);
			
			dayPanel.setBounds(190,20,70,90);
			dayPanel.add(dayModeText);
			dayPanel.add(dayButton);
			frame.add(dayPanel);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	/*
	 * This method is invoked when the user selects bright mode. It makes the game frame blue i.e. day mode!
	 */
	public void makeDay() {
		contentPane.setBackground(Color.BLUE);
	}
	
	public void addContrastOptions(JFrame frame) {
		JButton increaseContrast = new JButton("Increase contrast");
		increaseContrast.addActionListener(e -> increaseContrast());
		JButton decreaseContrast = new JButton("Decrease contrast");
		decreaseContrast.addActionListener(e -> decreaseContrast());
		
		JPanel contrastOptions = new JPanel();
		contrastOptions.add(increaseContrast);
		contrastOptions.add(decreaseContrast);
		contrastOptions.setBounds(80,120,120,120);
		frame.add(contrastOptions);
	}
	
	/*
	 * This method is invoked when the user selects to increase the contrast
	 * NOTE: This functionality is primarily based on the dominos and will be implemented in the future when the dominos become available
	 */
	public void increaseContrast() {
		JOptionPane.showMessageDialog(frame, "Functionality to be available soon!" , "Increase Contrast", JOptionPane.INFORMATION_MESSAGE);
	}
	
	/*
	 * This method is invoked when the user selects to decrease the contrast
	 * NOTE: This functionality is primarily based on the dominos and will be implemented in the future when the dominos become available
	 */
	public void decreaseContrast() {
		JOptionPane.showMessageDialog(frame, "Functionality to be available soon!" , "Decrease Contrast", JOptionPane.INFORMATION_MESSAGE);
	}
	
		
	




}



