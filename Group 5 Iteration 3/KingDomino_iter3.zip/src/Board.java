import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.MatteBorder;

/*
 * The Board class represents the board where the players kingdoms are built
 * @author Mahek Parmar
 */

public class Board extends JPanel{
	Color boardColor;
	JLabel playerNameLabel;
	String playerName;
	int playerNum;
	int row = 9;			//9*9 to allow 5*5 kingdoms to be built in any orientation
	int col=9;
	protected GridBox gridsToAdd[][];
	
	protected Boolean blocked;
	
	
	public Board(String playerName, int playerNum, Color boardColor) {
		super();
		this.playerName = playerName;
		this.boardColor = boardColor;
		this.playerNum =playerNum;
		blocked = true;				//by default every board is blocked
		getBoard();
	}

	/*
	 * This method creates a Board, taking into consideration the  color and name
	 * @return, the board for the player
	 */
	public JPanel getBoard() {
		
		JPanel topPanel = new JPanel();
		playerNameLabel = new JLabel("" + playerName +"'s Kingdom");
		playerNameLabel.setFont(new Font("Georgia", Font.BOLD, 15));
		playerNameLabel.setForeground(Color.BLACK);
		playerNameLabel.setHorizontalAlignment(JLabel.CENTER);
		playerNameLabel.setVerticalAlignment(JLabel.CENTER);
		topPanel.add(playerNameLabel);
		
		//we would the 9*9 board on the bottomPanel
		JPanel bottomPanel = new JPanel();							//creating a bottom panel
		bottomPanel.setLayout(new GridLayout(row, col));	//setting its layout to a grid layout so all the grids are equal
		
		gridsToAdd = new GridBox [row][col];				//a 2-d array that stores GridBox objects
		
		for (int i=0 ; i<row ; i++) {
			for (int j=0 ; j<col ; j ++) {
				gridsToAdd[i][j] = new GridBox(playerNum, i, j);				//adding the grids
				if (i==4 && j==4) {
					gridsToAdd[i][j].setText("k");
					gridsToAdd[i][j].setNotAvailable();						//centre most grid is occupied and not availalbe by default
					gridsToAdd[i][j].makeOccupied();
				}
				if ((i==3 && j==4) || (i==5 && j==4) || (i==4 && j==3) || (i==4 && j==5)) {		//by default on the tiles tiles adjacent (top, left,bottom,right) will be avialbale
					gridsToAdd[i][j].makeAvailable(boardColor);
				}
				gridsToAdd[i][j].setBackground(boardColor);		//the grid colors reflect the players chosen color for viewing
				bottomPanel.add(gridsToAdd[i][j]);	
			}
		}
		
		
		this.setLayout(new BorderLayout());
		this.add(topPanel, BorderLayout.NORTH);				//adding the corresponding top and bottom panels to the content pane of the frame
		this.add(bottomPanel, BorderLayout.CENTER);
		
		return this;
	}
	
	/*
	 * This method updates the name on the  board
	 * @param new_name, the new name to be presented on the board
	 */
	public void updateNameOnBoard(String new_name) {
		//NOTE : using try/catch as the method could also be called before the board is created
		try {
			//updating the name on the board's label
			playerNameLabel.setText(new_name +"'s Kingdom");
		}
		catch (Exception e){
			//do nothing
		}
	}
	
	/*
	 * This method updates the color on the board 
	 * @param color, the new color 
	 */
	public void updateColorOnBoard(Color color) {
		//again, using try/catch as the method can be called before the board is created
		try {
			playerNameLabel.setForeground(color);		//updates color of the text on the board
			for (int i=0 ; i<row ; i++) {
				for (int j=0 ; j<col ; j ++) {				//updates color of the board grids
					gridsToAdd[i][j].setBorder(new MatteBorder(1, 1, 1, 1, color));
					gridsToAdd[i][j].setBorderPainted(true);
					if (gridsToAdd[i][j].isAvailable()) {
						gridsToAdd[i][j].setBorder(new MatteBorder(3, 3, 3, 3, color));
					}
					}
			}
		}
		catch (Exception e){
			//do nothing
		}	
	}
	
	/*
	 * This method gets alls 2-d array that stores the individual grids in the board
	 * @return gridsToAdd, the 2-d array that contains the boards individual grids
	 */
	public GridBox[][] getBoardGrids() {
		return gridsToAdd;
	}
	
	/*
	 * This accessor method lets us know if the board is blocked or not
	 * @return blocked, a boolean, true when board is blocked, else false
	 */
	public Boolean isBlocked() {
		return blocked;
	}	

	/*
	 * This method block as board
	 */
	public void block() {
		blocked = true;
	}
	
	/*
	 * This method unblocks the board
	 */
	public void unblock() {
		blocked = false;
	}
	
	/*
	 * Accessor method that gets the number of rows in the board
	 * @return row, the number of rowns in the board
	 */
	public int getRowNumber() {
		return row;
	}
	
	/*
	 * Accessor method that gets the number of columns in the board
	 * @return col, the number of columns in the board
	 */
	public int getColNumber() {
		return col;
	}
	
	
	
}