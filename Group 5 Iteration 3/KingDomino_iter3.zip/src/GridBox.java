import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;

/*
* The GridBox class involves the grids/boxes which are the base of the whole game together with their interactive behaviors 
* NOTE: this class is used as it will help us for future functionalities, more implementation will be added to this class in the future
* @author  Mahek Bharat Parmar

*/

public class GridBox extends JButton {

	protected Boolean isAvailable;
	protected int boardNumber;
	protected int xIndex;
	protected int yIndex;

	protected Boolean isAdjacent;		//if a gridbox is adjacent(top,bottom,left or right) to the gridbox where one side of a domino was just placed
	protected Boolean isOccupied;		//if a gridbox is occupied or not

	public GridBox(int parentBoard, int xIndex, int yIndex) {
		super();
		isAvailable = false;
		boardNumber = parentBoard;				//represents which players board the grid is in
		this.xIndex = xIndex;					//position of the individual gridboxes 
		this.yIndex = yIndex;
		isAdjacent = false;
		isOccupied = false;
		

	}
	
	/*
	 * Accessor method that tells us if the gridbox is occupied or not
	 * @return isOccupied, if true it is occupied, else false
	 */
	public Boolean isOccupied() {
		return isOccupied;
	}
	
	/*
	 * This method Makes a gridBox occupied
	 */
	public void makeOccupied() {
		isOccupied = true;
	}

	/*
	 * This method returns the x position of the gridbox if it were to be added to a board
	 * @return xIndex, the x position of the gridbox in the board
	 */
	public int getXIndex() {
		return xIndex;
	}
	
	/*
	 * This method returns the y position of the gridbox if it were to be added to a board
	 * @return xIndex, the y position of the gridbox in the board
	 */
	public int getYIndex() {
		return yIndex;
	}

	/*
	 * Accessor method that tells us if the gridbox is available or not
	 * @return isAvailable, if true it is occupied, else false
	 */
	public Boolean isAvailable() {
		return isAvailable;
	}

	/*
	 * This method sets a gridbox as not available
	 */
	public void setNotAvailable() { // done when picked
		isAvailable = false;
	}

	/*
	 * This method makes a gridbox available
	 * @param color
	 */
	public void makeAvailable(Color color) {   //at most only 3 adjacent neighbours are available once a tile is chosen
		isAvailable = true;
		this.setBorder(new MatteBorder(3, 3, 3, 3, color));
	}
	
	
	/*
	 * Accessor method that tells us the boardnumber in which the gridbox belongs to
	 * @return boardNumber, an int value that represents the board number in which the gridbox is found
	 */
	public int getBoardNumber() {
		return boardNumber;
	}

	/* Accessor method that tells us if the gridbox is adjacent to another one
	 * @return isAdjacent, a Boolean, true if the gridbox is adjacent to the other
	 */
	public Boolean isAdjacent() {
		return isAdjacent; 
	}
	
	/*
	 * This method makes a gridBox adjacent to another one
	 * @param color
	 */
	public void setAdjacent(Color color) { 
		isAdjacent = true; 
		this.setBorder(new MatteBorder(3,3,3,3,color)); 
	}


}