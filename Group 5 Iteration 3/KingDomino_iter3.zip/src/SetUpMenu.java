import java.awt.*;
import javax.swing.*;


/*
 * This class allows users to set-up the game based on the number of players
 * We identify how many players want to play
 * @author Mahek Parmar
 */
public class SetUpMenu {
	private static JFrame frame;

	Container contentPane;
	public SetUpMenu() {
		//creating and managing the frame
		frame = new JFrame("KingDomino - Setup Window");
		contentPane = frame.getContentPane();
		contentPane.setLayout(null);
		frame.setPreferredSize(new Dimension(500,500));
		
		setUp();
		//housekeeping code
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
	
	}
	
	/*
	 * This method sets up the setUp window asking how many players want to play the game
	 */
	public void setUp() {
		//asking how many players, and dealing with their orientation
		JLabel noOfPlayers = new JLabel ("How many players?");
		noOfPlayers.setFont(new Font("Georgia", Font.PLAIN, 50));
		noOfPlayers.setForeground(Color.RED);
		noOfPlayers.setVerticalAlignment(JLabel.CENTER);
		noOfPlayers.setHorizontalAlignment(JLabel.CENTER);
		JPanel howManyPlayers = new JPanel();
		howManyPlayers.setBounds(0,50,500,200);
		howManyPlayers.add(noOfPlayers);
		
		//buttons for every number of possible players i.e. 2,3 or 4 and their corresponding action listeners
		JButton two = new JButton("2");
		two.setFont(new Font("Georgia", Font.PLAIN, 75));
		two.setVerticalAlignment(JLabel.CENTER);
		two.setHorizontalAlignment(JLabel.CENTER);
		two.addActionListener(e-> setUpPlayers(2));
		JPanel twoP = new JPanel();
		twoP.setBounds(50,250, 100, 105);
		twoP.add(two);
	
		

		JButton four = new JButton("4");
		four.setFont(new Font("Georgia", Font.PLAIN, 75));
		four.setVerticalAlignment(JLabel.CENTER);
		four.setHorizontalAlignment(JLabel.CENTER);
		four.addActionListener(e-> setUpPlayers(4));
		JPanel fourP = new JPanel();
		fourP.setBounds(350,250, 100, 105);
		fourP.add(four);
		
		//bringing everything together in the frame
		contentPane.add(howManyPlayers);
		contentPane.add(twoP);
		contentPane.add(fourP);
	}	
	
	
	/*
	 * This method helps us create the game based on how many players are playing 
	 * @param noOfPlayers the number of players who want to play the game
	 * 
	 */
	private static void setUpPlayers(int noOfPlayers) {
		frame.dispose();				//clsoing the current frame
		SetUpPlayers set_up = new SetUpPlayers(noOfPlayers);		//creating a SetUpPlayers instance
	
	}
}
