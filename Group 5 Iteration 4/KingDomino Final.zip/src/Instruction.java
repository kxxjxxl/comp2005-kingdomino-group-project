import java.awt.Dimension;
import java.util.*;
import java.util.*;

import javax.swing.*;


/*
 * This is a simple class that provides instructions to the User on how to play and some game related rules
 * @author Mahek Bharat Parmar
 * 
 */
public class Instruction {

	JFrame frame;
	ArrayList<String> ruleFiles;			//this arrayList stores all the pictures for our rules
	JPanel rulePanel;
	JLabel ruleLabel;
	public Instruction() {
		
		frame = new JFrame("Quick Guide");
		ruleFiles = new ArrayList<>(Arrays.asList("r1.jpg", "r2.jpg", "r3.jpg", "r4.jpg", "r5.jpg" , "r6.jpg"));
		frame.setPreferredSize(new Dimension(880,500));
		
		frame.setLayout(null);
		frame.setResizable(false);
		showInstructions();	
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
	}
	
	/*
	 * This function helps display the rule images
	 */
	public void showInstructions() {
		
		rulePanel = new JPanel();
		ImageIcon r1 = new ImageIcon(Instruction.class.getResource("" + ruleFiles.remove(0)));
		ruleLabel = new JLabel(r1);
		rulePanel.setBounds(0,0,850,400);
		rulePanel.add(ruleLabel);
		frame.add(rulePanel);
		
		ImageIcon nextImage = new ImageIcon(Instruction.class.getResource("next.jpg"));
		JButton nextButton = new JButton(nextImage);
		nextButton.setBorderPainted(false);
		nextButton.setBounds(810,410,50,60);

		nextButton.addActionListener(e -> nextRule());			//when the next button is clicked, the next rule is displayed
		
		frame.add(nextButton);
	}
	
	
	/*
	 * This method is called whenever the user clicks the next button on the rules frame
	 * 
	 */
	private void nextRule() {
		//we display every rule once, once the next button is clicked, the next rule is loaded until there are no rules left
		if (!(ruleFiles.isEmpty())){
			String file = ruleFiles.remove(0);
			ImageIcon r = new ImageIcon(Instruction.class.getResource(""+file));
			ruleLabel.setIcon(r);
			frame.pack();
		}
		//when there are no rules left, the frame is disposed
		else {
			frame.dispose();
		}
	}
	
}
