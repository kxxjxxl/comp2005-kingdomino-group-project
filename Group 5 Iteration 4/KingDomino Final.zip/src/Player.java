import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;

/*
 * The Player class represents the actual player and its various attributes
 * @author Mahek Parmar
 */
public class Player{
	protected int playerID;
	protected String playerType;
	protected Color playerColor;
	protected String playerName;
	JLabel playerNameLabel;
	Board playerBoard;
	protected int playerScore;
	
	//represent the row and column choice for the board
	protected int row = 5;
	protected int col = 5;
	
	private ArrayList<JButton> buttonList = new ArrayList<>();;
	protected GridBox gridsToAdd[][];

	protected int playerStars;
	public Player(int id) {
		playerID = id;
		playerColor = Color.black;
		playerName = "Player " + id;			//by default the player name would be Player followed by its number, for eg => Player 1
		playerBoard = new Board(playerName, playerID, playerColor);
		playerScore =0;			//initially for every player
		playerStars = 0;
	}
	
	/*
	 * Accessor method that returns the Player's score
	 * @return playerScore, an int representing the Player's score
	 */
	protected int getPlayerScore() {
		return playerScore;
	}
	
	/*
	 * This method increments the player's score
	 * When scores are calculated, the subscores i.e. scores of the different paths in the player kingdom add up to form 
	 * the players final score
	 * @param s, the score of the path to add
	 */
	protected void addToPlayerScore(int s) {
		playerScore += s;
	}
	
	/*
	 * An accessor method to returns the number of stars/crowns in the players kingdom/board
	 * @ playerStars, the number of stars in the players kingdom/board
	 */
	protected int getPlayerStars() {
		return playerStars;
	}
	
	/*
	 * This method increments the player's stars
	 * When the total stars in the players kingdom/board are calculated, the stars of each path are added to final the final 
	 * total number of stars in the players kingdom score
	 * @param s, the score of the path to add
	 */
	protected void setPlayerStars(int s) {
		playerStars += s;
	}
	
	/*
	 * Accessor method to get the playerID
	 * @return playerID, the players ID
	 */
	protected int getPlayerID() {
		return playerID;
	}

	/*
	 * Accessor method to get the playerType
	 * @return playerType, the type of the player (human or AI) 
	 */
	protected String getType() {
		return playerType;
	}
	
	/*
	 * Accessor method to get the player's Color
	 * @return playerColor, the players Color
	 */
	protected Color getColor() {
		return playerColor;
	}

	/*
	 * Accessor method to get the player's name
	 * @return playerName, the players name
	 */
	protected String getPlayerName() {
		return playerName;
	}

	/*
	 * Mutator method to update the players color
	 * @param color, the color to update
	 */
	protected void updatePlayerColor(Color color) {
		playerColor = color;
	}
	
	/*
	 * Mutator method to update the players name
	 * @param newName, the name to be updated
	 */
	public void updatePlayerName(String newName) {
		playerName = newName;
		playerBoard.updateNameOnBoard(newName);		//makes an internal method call to update the name on the board too
		
	}
	
	/*
	 * Accessor method which returns the player Board
	 * @return playerBoard, a Board Object
	 */
	public Board getPlayerBoard() {
		return playerBoard;
	}
	
	/*
	 * This method returns the grids that form the Board
	 * @return a 2-d array containing all the board grids
	 */
	public GridBox [][] getBoardGrids(){
		return playerBoard.getBoardGrids();
	}

	/*
	 * This method creates a color pallet for the players
	 * @return colorPallet, the color pallet
	 */
	protected JPanel getColorPallet() {
		
		JPanel colorPallet = new JPanel();
		colorPallet.setLayout(new GridLayout(2,1));
		colorPallet.add(getRegularColorPallet());				//regular color pallet that contains regular normal colors
		colorPallet.add(getProtanopiaColorPallet());			//protanopia color pallet that contains colors that aid ppl with protanopia (main type of color deficiency)
		return colorPallet;
	}
	
	/*
	 * This method helps create the regular color pallet
	 * @return regularColorPallet, the color pallet containing all the regular colors
	 */
	protected JPanel getRegularColorPallet() {
		// NOTE: every color in the pallet is implemented as a button allowing the user the select it
		//       Upon selection this updates the playerColor and also the board and labels related to that particular player
		//       aiding their color vision
		
		JButton redButton = new JButton();
		redButton.setBackground(Color.RED);
		redButton.addActionListener(e-> setToRed(redButton));
		
		JButton greenButton = new JButton();
		greenButton.setBackground(Color.GREEN);
		greenButton.addActionListener(e-> setToGreen(greenButton));
		
		JButton darkGreenButton = new JButton();
		darkGreenButton.setBackground(new Color(0,77,64));
		darkGreenButton.addActionListener(e-> setToDarkGreen(darkGreenButton));
		
		JButton blueButton = new JButton();
		blueButton.setBackground(Color.BLUE);
		blueButton.addActionListener(e-> setToBlue(blueButton));
		
		//this buttonList arrayList contains all the color pallet buttons, so that we can only allow 1 color to be selected at once
		
		buttonList.add(redButton);
		buttonList.add(blueButton);
		buttonList.add(darkGreenButton);
		buttonList.add(greenButton);
		
		JPanel regularColorPallet = new JPanel();
		regularColorPallet.setLayout(new GridLayout(1,4));

		regularColorPallet.add(redButton);
		regularColorPallet.add(greenButton);
		regularColorPallet.add(blueButton);
		regularColorPallet.add(darkGreenButton);
		
		return regularColorPallet;
	}
	
	/*
	 * This method helps create the protanopia color pallet aiding people with protanopia color difficiency
	 * @return protanopiaColorPallet, the color pallet containing all the protanopis colors
	 */
	protected JPanel getProtanopiaColorPallet() {
		//NOTE; here we are using custom customs created based on RGB composition, this choice was made based on research on protanopia colors
		//      Again every color is implemented as a button that updates the playerColor and reflects the change on the players board and labels
		
		JButton darkGreyButton = new JButton();
		darkGreyButton.setBackground(Color.GRAY);
		darkGreyButton.addActionListener(e-> setToDarkGrey(darkGreyButton));
		
		JButton darkBlueButton = new JButton();
		darkBlueButton.setBackground(new Color(49,60,147));
		darkBlueButton.addActionListener(e-> setToDarkBlue(darkBlueButton));
		
		JButton greyBlueButton = new JButton();
		greyBlueButton.setBackground(new Color(102,153,204));
		greyBlueButton.addActionListener(e-> setToGreyBlue(greyBlueButton));
		
		JButton moderateYellowButton = new JButton();
		moderateYellowButton.setBackground(new Color(180,170,60));
		moderateYellowButton.addActionListener(e-> setToModerateYellow(moderateYellowButton));
		
	
		buttonList.add(darkGreyButton);
		buttonList.add(darkBlueButton);
		buttonList.add(greyBlueButton);
		buttonList.add(moderateYellowButton);
		
		
		JPanel protanopiaColorPallet = new JPanel();
		protanopiaColorPallet.setLayout(new GridLayout(1,4));

		protanopiaColorPallet.add(darkGreyButton);
		protanopiaColorPallet.add(darkBlueButton);
		protanopiaColorPallet.add(greyBlueButton);
		protanopiaColorPallet.add(moderateYellowButton);
		
		return protanopiaColorPallet;
	}
	
	/*
	 * This method updates the player's color when the player selects the red color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToRed(JButton button) {
		removeOthersBorder(button);		//internal method call to a method that removes the selection border from all the other colors
		updatePlayerColor(Color.RED);
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));			//visually helps us see which color was selected
		button.setBorderPainted(true);
		playerBoard.updateColorOnBoard(Color.RED);			//internal method call that updates the color on the players board and label too		
	}
	
	/*
	 * This method updates the player's color when the player selects the blue color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToBlue(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(Color.BLUE);
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		playerBoard.updateColorOnBoard(Color.BLUE);
	}
	
	/*
	 * This method updates the player's color when the player selects the green color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToGreen(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(Color.GREEN);
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		playerBoard.updateColorOnBoard(Color.GREEN);
	}
	
	/*
	 * This method updates the player's color when the player selects the yellow color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToDarkGreen(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(new Color(0,77,64));
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		playerBoard.updateColorOnBoard(new Color(0,77,64));
	}
	
	/*
	 * This method updates the player's color when the player selects the soft yellow color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */	
	protected void setToDarkGrey(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(Color.GRAY);
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		playerBoard.updateColorOnBoard(Color.GRAY);
	}
	
	/*
	 * This method updates the player's color when the player selects the dark blue color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToDarkBlue(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(new Color(49,60,147));
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		playerBoard.updateColorOnBoard(new Color(49,60,147));
	}
	
	/*
	 * This method updates the player's color when the player selects the frey blue color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToGreyBlue(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(new Color(102,153,204));
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		playerBoard.updateColorOnBoard(new Color(102,153,204));
	}
	
	/*
	 * This method updates the player's color when the player selects the  moderate yellow color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToModerateYellow(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(new Color(180,170,60));
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		playerBoard.updateColorOnBoard(new Color(180,170,60));
	}
	
	/*
	 * This method removes the selection border from all the colors except from the currently chosen color
	 * @param button, the JButton representing a color that the player chose
	 */
	protected void removeOthersBorder(JButton button) {
		//give an empty border for all other colors in the pallet except for this chosen color
		for (int i=0 ; i<buttonList.size() ; i++) {
			if (buttonList.get(i) != button) {
				buttonList.get(i).setBorder(new EmptyBorder(2,2,2,2));
			}
		}
		
	}

}
