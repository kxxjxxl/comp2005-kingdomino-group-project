import java.awt.*;
import java.util.Random;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;

/*
* The GridBox class involves the grids/boxes which are the base of the whole game together with their interactive behaviors 
* NOTE: this class is used as it will help us for future functionalities, more implementation will be added to this class in the future
* @author  Mahek Bharat Parmar

*/

public class GridBox extends JButton {

	protected int boardNumber;
	protected int xIndex;
	protected int yIndex;
	
	protected Boolean isAvailable;		//if a gridbox is available for domino palcement, provided types match
	protected Boolean isAdjacent;		//if a gridbox is adjacent(top,bottom,left or right) to the gridbox where one side of a domino was just placed
	protected Boolean isOccupied;		//if a gridbox is occupied or not
	protected Boolean outOfBounds;		//if a gridbox is out of bounds or not, since we build only a 5*5 kingdom
	protected Boolean isCounted;		//if a gridbox has been counted or not, for scoring purposes
	
	protected String terrain;			//domino attributed passed on 
	protected int stars;
	
	protected String currentFileName;
	protected JLabel label;
	
	Random randgen = new Random();

	public GridBox(int parentBoard, int xIndex, int yIndex) {
		super();
		this.setBorder(new MatteBorder(1,1,1,1,Color.black));
		isAvailable = false;
		boardNumber = parentBoard;				//represents which players board the grid is in
		this.xIndex = xIndex;					//position of the individual gridboxes 
		this.yIndex = yIndex;
		isAdjacent = false;
		isOccupied = false;
		outOfBounds = false;
		isCounted = false;
		label = new JLabel();
	}
	
	public GridBox() {
		super();
	}
	
	/*
	 * Accessor method to helps us identify if the gridbox has been counted or not
	 * @return isCounted, a Boolean representing the gridbox was counted when True, else vicevers
	 */
	public Boolean isCounted() {
		return isCounted;
	}
	
	/*
	 * Mutator method that sets the status of the gridbox as already counted
	 */
	public void setCounted() {
		isCounted = true;
	}
	
	/*
	 * Accessor method that tells us if the gridbox is occupied or not
	 * @return isOccupied, if true it is occupied, else false
	 */
	public Boolean isOccupied() {
		return isOccupied;
	}
	
	/*
	 * Accessor method that gets the terrain type in the gridbox
	 * @return terrain, a String representing the terrain type in the gridBox
	 */
	public String getTerrain() {
		return terrain;
	}
	
	/*
	 * Accessor method that tells us if the number of stars in the gridbox
	 * @return stars, the number of stars in the gridbox
	 */
	public int getStars() {
		return stars;
	}
	
	/*
	 * Mutator method that tells us change the number of stars in a gridbox (i.e. when a Domino is placed on it)
	 * @param s, the number of stars in the gridbox
	 */
	public void setStars(int s) {
		stars =s;
	}
	
	/*
	 * Mutator method that tells us change the terrain type in a gridbox (i.e. when a Domino is placed on it)
	 * @param t, the terrain type of the gridbox
	 */
	public void setTerrain(String t) {
		terrain = t;
	}
	
	/*
	 * This method Makes a gridBox occupied
	 */
	public void makeOccupied() {
		isOccupied = true;
		
		
	}

	/*
	 * This method returns the x position of the gridbox if it were to be added to a board
	 * @return xIndex, the x position of the gridbox in the board
	 */
	public int getXIndex() {
		return xIndex;
	}
	
	/*
	 * This method returns the y position of the gridbox if it were to be added to a board
	 * @return xIndex, the y position of the gridbox in the board
	 */
	public int getYIndex() {
		return yIndex;
	}

	/*
	 * Accessor method that tells us if the gridbox is available or not
	 * @return isAvailable, if true it is occupied, else false
	 */
	public Boolean isAvailable() {
		return isAvailable;
	}
	
	public void setCurrentFileName(String fName) {
		currentFileName = fName;
	}

	/*
	 * This method sets a gridbox as not available
	 */
	public void setNotAvailable() { // done when picked
		isAvailable = false;
	}

	/*
	 * This method makes a gridbox available
	 * @param color
	 */
	public void makeAvailable(Color color) {   //at most only 3 adjacent neighbours are available once a tile is chosen
		isAvailable = true;
		this.setBorder(new MatteBorder(3, 3, 3, 3, color));
	}
	
	/*
	 * Accessor method that tells us the boardnumber in which the gridbox belongs to
	 * @return boardNumber, an int value that represents the board number in which the gridbox is found
	 */
	public int getBoardNumber() {
		return boardNumber;
	}

	/* Accessor method that tells us if the gridbox is adjacent to another one
	 * @return isAdjacent, a Boolean, true if the gridbox is adjacent to the other
	 */
	public Boolean isAdjacent() {
		return isAdjacent; 
	}
	
	/*
	 * This method makes a gridBox adjacent to another one
	 * @param color
	 */
	public void setAdjacent(Color color) { 
		isAdjacent = true; 
		this.setBackground(color); 
	}
	
	/*
	 * This method sets the adjacency status to false
	 */
	public void setNotAdjacent() {
		isAdjacent = false;
		//removes the background color which represented an adjacent position
		this.setBackground(Color.white);
	}
	
	/*
	 * Accesor method that helps us identify whether the gridbox is out of bounds or not
	 * @param outOfBounds, represents the out of bounds status of the gridbox
	 */
	public Boolean isOutOfBounds() {
		return outOfBounds;
	}
	
	/*
	 * This method makes a gridbox out of bounds
	 */
	public void makeOutOfBounds() {
		outOfBounds = true;
		this.setIcon(null);
		this.setText("X");
		this.setBorder(null);
		
		 
	}
	
	/*
	 * This function provides a random number
	 * A simple helper method for the makeOutOfBounds() functions 
	 */
	public int getRandomNumber() {
		return randgen.nextInt(3);
	}
	
	/*
	 * This function allows us to increase the contrast of the dominos in the gridbox of the board
	 * @param currentContrast, an int representing the contrast level desired
	 */
	public void increaseContrast(int currentContrast) {
		//getting the current file name of the gridbox
		
		currentFileName = this.getIcon().toString();
		//getting only the raw file name (gets rids of the source path)
		currentFileName = currentFileName.substring(currentFileName.length() - 9);
		
		if (currentContrast==1) {
			//if current contrast is medium, change it to high
			currentFileName = currentFileName.replace("lc", "hc");
		}
		if (currentContrast == 0) {
			//if currentcontrast is low, change it to medium
			currentFileName = currentFileName.replace("nc", "lc");
		
		}
		ImageIcon updated = new ImageIcon(GridBox.class.getResource(currentFileName));
		this.setIcon(updated);

		//Note: if current contrast is 2/high, do nothing as thats our maximum contrast level
	}
	
	/*
	 * This function allows us to decrease the contrast of the dominos in the gridbox of the board
	 * @param currentContrast, an int representing the contrast level desired
	 */
	public void decreaseContrast(int currentContrast) {
		//getting the current file name of the gridbox
		currentFileName = this.getIcon().toString();
		//getting only the raw file name (gets rids of the source path)
		currentFileName = currentFileName.substring(currentFileName.length() - 9);
		
		if (currentContrast==1) {
			//if current contrast is medium, change it to low
			currentFileName = currentFileName.replace("lc", "nc");
		}
		if (currentContrast == 2) {
			//if current contrast is high, change it to medium
			currentFileName = currentFileName.replace("hc", "lc");
			
		}
		ImageIcon updated = new ImageIcon(GridBox.class.getResource(currentFileName));
		this.setIcon(updated);
		//Note: if current contrast is 0/low, do nothing as thats our minimum contrast level
	}

	
	/*
	 * This method changes a GridBox's appearance to support the Raw mode
	 */
	public void changeToRawMode() {
		if (isOccupied()) {
			this.setIcon(null);		
			this.setText("" + Character.toUpperCase(getTerrain().charAt(0)) + "(" +getStars() +")");
		}
		if (isOutOfBounds()) {
			this.setIcon(null);
			this.setText("X");
		}
	}
	
	/*
	 * This method allows terrain placement to reflect Raw Mode
	 */
	public void addRawTerrain() {
		this.setIcon(null);
		this.setText("" + Character.toUpperCase(getTerrain().charAt(0)) + "(" +getStars() +")");
	}
	
	/*
	 * This method removes the Raw Mode settings from a GridBox
	 */
	public void exitRawMode() {
		this.setText("");
		if (isOccupied()) {	
			if (getTerrain().equals("king")) {
				this.setIcon(new ImageIcon(GridBox.class.getResource("king.jpg")));
			}
			else {
				this.setIcon(new ImageIcon(GridBox.class.getResource(currentFileName)));
				this.setBorder(null);
			}
		}
		if (isOutOfBounds()) {
			this.makeOutOfBounds();
		}
	}
}