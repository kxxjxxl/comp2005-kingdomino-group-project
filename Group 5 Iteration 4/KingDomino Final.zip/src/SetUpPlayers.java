import java.awt.*;
import javax.swing.*;
import java.util.*;

/*
 * This class allows us to collect player related information for each player
 * Information such as player name, players chosen color and so on.
 * @author Mahek Parmar
 */

public class SetUpPlayers {
	
	protected static JFrame frame;
	protected static Container contentPane;
	private ArrayList<Player> playerList;			//this arraylist stores the Player objects playing the game
	
	
	//private JLabel playerName;
	
	public SetUpPlayers(int noOfPlayers) {
		playerList = new ArrayList<>();
		//building and organizing the frame
		frame = new JFrame("Player Settings");
		contentPane = frame.getContentPane();
		contentPane.setLayout(null);
		frame.setPreferredSize(new Dimension(650,550));

		setUp(noOfPlayers);
		//housekeeping code
		
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
		
	}
	
	/*
	 * Based on how many players want to play the game, this method instantiates that number of players and stores them to our playerList arraylist
	 * @param noOfPlayers, the number of players who are playing the game
	 */
	private void setUp(int noOfPlayers) {
		for (int i = 1 ; i<=noOfPlayers ; i++) {
			playerList.add(new Player(i));
		}
		addDetails();			//internal method call
	}
	
	/*
	 * This method gathers the player information from the user input
	 */
	public void addDetails() {
		//calls a helper class that helps us collect information about a player
		PlayerDetails displayDetails = new PlayerDetails(playerList, frame);
			
		//code for the next step image
		try {
			ImageIcon nextImage = new ImageIcon(SetUpPlayers.class.getResource("next.jpg"));
			JButton nextButton = new JButton(nextImage);
			nextButton.setBorderPainted(false);
			nextButton.addActionListener(e -> {
				try {
					startGame();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			});			//when the next button is clicked, after getting all player info, then we start the actual game
			JPanel nextPanel = new JPanel();
			nextPanel.add(nextButton);
			nextPanel.setBounds(580,450,50,60);
			frame.add(nextPanel);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
		
	/*
	 * This method initiates the game
	 */
	public void startGame() throws Exception {
		frame.dispose();
		GameUI board = new GameUI(playerList);
		
	}	

}
