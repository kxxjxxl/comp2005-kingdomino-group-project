import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.*;

import javax.swing.*;

/*
 * This class provides a different frame with the necessary details when the game is completed
 * @author Mahek Bharat Parmar
 */

public class EndGame {
	
	protected JFrame gameFrame;					//original frame where the game was played
	protected JFrame endGameFrame;
	protected ArrayList<Player> playerList;				//at this point, the playerList contains Players sorted according to their scores in DESC
	
	public EndGame(JFrame frame, ArrayList<Player> playerList) {
		gameFrame = frame;
		endGameFrame = new JFrame("Scores");
		this.playerList = playerList;
		setUpFrame();
		endGameFrame.setVisible(true);
		
		//housekeeping code
		endGameFrame.pack();
		endGameFrame.setLocationRelativeTo(null);
		endGameFrame.setResizable(false);
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
		
	}
	
	/*
	 * This method sets up the frame when the game is completed
	 */
	public void setUpFrame() {
		endGameFrame.setPreferredSize(new Dimension(400,400));	
		endGameFrame.setLayout(null);
		
		JPanel scoreSheet = new JPanel();
		scoreSheet.setLayout(new GridLayout(5,1));
		JLabel heading = new JLabel("Scores");
		heading.setFont(new Font("Georgia", Font.BOLD, 35));
		heading.setHorizontalAlignment(JLabel.CENTER);
		scoreSheet.add(heading);
		
		//gets the player's names and scores and prints then according to their preferred choice of color
		for (int i=0 ; i< playerList.size() ; i++){
			JLabel playerScore = new JLabel ("" + (i+1) + ") " + playerList.get(i).getPlayerName() + " -----> " + playerList.get(i).getPlayerScore());
			playerScore.setForeground(playerList.get(i).getColor());
			playerScore.setFont(new Font("Georgia", Font.BOLD, 25));
			scoreSheet.add(playerScore);
		}
		
		scoreSheet.setBounds(20,20,400,170);
		endGameFrame.add(scoreSheet);
		
		//Adding 2 buttons - one to start a new game, the other to exit the game
		JButton newGameButton = new JButton("Play again!");
		newGameButton.setFont(new Font("Georgia", Font.BOLD, 20));
		newGameButton.setVerticalAlignment(JLabel.CENTER);
		newGameButton.setHorizontalAlignment(JLabel.CENTER);
		newGameButton.setBounds(30,250,150,40);
		newGameButton.addActionListener(e-> startNewGame());			//adding the action listeners
		
		JButton exitGameButton = new JButton("Exit");
		exitGameButton.setBounds(210, 250, 150, 40);
		exitGameButton.setFont(new Font("Georgia", Font.BOLD, 20));
		exitGameButton.setVerticalAlignment(JLabel.CENTER);
		exitGameButton.setHorizontalAlignment(JLabel.CENTER);
		exitGameButton.addActionListener(e -> terminate());					//adding the action listeners
		
		endGameFrame.add(newGameButton);
		endGameFrame.add(exitGameButton);
		
	}
	
	/*
	 * This method is called when the user clicks the Play Again button.
	 * It allows the user to play a new game
	 */
	public void startNewGame() {
		//calling our Driver class and hence restarting the whole game
		HomeScreen.mainCaller();
		//disposing all the frames pertaining to the current game
		gameFrame.dispose();
		endGameFrame.dispose();
	}
	
	/*
	 * This function is called when the user cliks the Exit button
	 * It exits the program
	 */
	public void terminate() {
		System.exit(0);
	}

}
