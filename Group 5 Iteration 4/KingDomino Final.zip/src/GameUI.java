import java.awt.*;
import javax.swing.*;
import javax.swing.border.MatteBorder;

import java.util.*;

/*
 * This class represents the main GUI where KingDomino is played
 * @author Mahek Parmar
 * 
 */
public class GameUI {
	protected ArrayList<Player> playerList;
	protected JFrame frame;
	protected Container contentPane;
	
	protected static int currentContrast=0;
	protected JLabel contrastLabel;
	
	
	public GameUI(ArrayList<Player> playerList) throws Exception {
		//set-up and housekeeping code
		this.playerList = playerList; 
		frame = new JFrame("KingDomino");
		 
		frame.setLayout(null);
		frame.setPreferredSize(new Dimension(1920,830));
		

		contentPane = frame.getContentPane();
		contentPane.setLayout(null);
		contrastLabel = new JLabel();
		
		
		
		
		setUpBoard(); 					//internal method call to set up the board
		Game playGame = new Game(playerList, frame);
		currentContrast =1;
		
				
		frame.setVisible(true);
		frame.setResizable(false); 
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
		
	}
	
	
	/*
	 * This method setups the Board for every player playing the game
	 * 
	 */
	public void setUpBoard() {
		for (Player player: playerList) {
			 
			Board playerBoard = player.getPlayerBoard();			//gets the playerBoard
			
			//here we position the board on the GUI based on which player it is
			if (player.getPlayerID() ==1) {
				playerBoard.setBounds(50,20,360,360);
			}
			else if (player.getPlayerID() == 2) {
				playerBoard.setBounds(1050,20,360,360);
			}
			else if (player.getPlayerID() == 3) {
				playerBoard.setBounds(50,420,360,360);
			}
			else {
				playerBoard.setBounds(1050,420,360,360);
			}
			
			contentPane.add(playerBoard);			
		}
		
		//internal method calls to add the player and display settings on the GUI
		addPlayerSettings();
		addDisplaySettings();
		addGuideBar();
		}
	
	/*
	 * This methods adds the guide button to the game frame
	 */
	public void addGuideBar() {
		JButton guideButton = new JButton("Guide");
		guideButton.addActionListener(e -> showGuide());		//this functionality will come in later methods
		guideButton.setFont(new Font("Georgia", Font.BOLD, 14));
		guideButton.setBorder(new MatteBorder(2,2,2,2,Color.black));
		//putting everything together
		
		guideButton.setBounds(1420,710,100,30);
		frame.add(guideButton);
	}
	
	/*
	 * This method shows the Instruction frame
	 */
	public void showGuide() {
		Instruction i = new Instruction();
	}
	
	/*
	 * This method deals with adding the player setting functionality to the game frame
	 * It adds a settings buttons which brings up a frame that allows us to select player settings
	 * 
	 */
	public void addPlayerSettings() {
		//the setting icon, put into the button
		
		try {
			ImageIcon settings = new ImageIcon(GameUI.class.getResource("settings.jpg"));
			JButton settingsButton = new JButton(settings);
			settingsButton.addActionListener(e -> showPlayerSettings());
			
			JPanel settingsPanel = new JPanel();
			settingsPanel.setBounds(1450,0,75,75);
			settingsPanel.add(settingsButton);
			
			contentPane.add(settingsPanel);				
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	/*
	 * This method shows/provides the player settings when the user elects to change the player settings
	 * 
	 */
	public void showPlayerSettings() {
		JFrame settingsFrame = new JFrame ("Player Settings");
		settingsFrame.setLayout(null);
		settingsFrame.setPreferredSize(new Dimension(600,500));
		
		PlayerDetails playerDetails = new PlayerDetails(playerList, settingsFrame);			//making use of the PlayerDetails class to provde to build the GUI for player settings
		
		//housekeeping code
		settingsFrame.pack();
		settingsFrame.setLocationRelativeTo(null);
		settingsFrame.setVisible(true);
		settingsFrame.setResizable(false);
		
	}
	
	/*
	 * This method adds the display settings functionality to the game frame
	 * It adds a display settings button which brinds up a frame containing the various display settings
	 */
	public void addDisplaySettings() {
		
		
		JButton displayButton = new JButton("Display Settings");
		displayButton.setFont(new Font("Georgia", Font.BOLD, 11));
		displayButton.setBorder(new MatteBorder(2,2,2,2,Color.black));
		displayButton.addActionListener(e -> showDisplaySettings());
		displayButton.setBounds(1420,760,100,30);
		frame.add(displayButton);
	}
	
	/*
	 * This method provides us the various display settings when the user clicks the display settings button
	 * 
	 */
	public void showDisplaySettings() {
		JFrame displayFrame = new JFrame("Display Settings");
		displayFrame.setLayout(null);
		displayFrame.setPreferredSize(new Dimension(300,250));
		
		contrastLabel.setBounds(45,190,220,20);
		displayFrame.add(contrastLabel);
		adjustContrastLabel();
		
		
		
		//adding the different display setting options to the displayFrame
		addDarkMode(displayFrame);
		addBrightMode(displayFrame);
		addDayMode(displayFrame);
		addContrastOptions(displayFrame);
		
		//housekeeping code
		displayFrame.pack();
		displayFrame.setLocationRelativeTo(null);
		displayFrame.setVisible(true);
		displayFrame.setResizable(false);
	
	}
	
	/*
	 * This method updates the contrast levels when they are changed
	 */
	public void adjustContrastLabel() {
		String namedContrast = "";
		if (currentContrast == 0) {
			namedContrast = "Low";
		}
		else if (currentContrast == 1) {
			namedContrast = "Normal";
		}
		else if (currentContrast == 2) {
			namedContrast = "High";
		}
		contrastLabel.setText("Current Contrast : " + namedContrast);
		contrastLabel.setFont(new Font ("Georgia", Font.BOLD, 15));
	}
	
	/*
	 * This method makes the game frame support the dark mode
	 * @param frame, the display frame where we add this functionality
	 */
	public void addDarkMode(JFrame frame) {
		//creating the label and button for the 'dark mode'
		
		
		try {
			ImageIcon darkImage = new ImageIcon(GameUI.class.getResource("dark.jpg"));
			JButton darkButton = new JButton(darkImage);
			darkButton.addActionListener(e -> makeDark());
			
			JPanel darkPanel = new JPanel();
			
			JLabel darkModeText = new JLabel("Dark Mode");
			darkModeText.setFont(new Font("Georgia" , Font.ITALIC, 10));
			darkModeText.setVerticalAlignment(JLabel.CENTER);
			darkModeText.setHorizontalAlignment(JLabel.CENTER);
			
			darkPanel.setBounds(10,20,70,90);
			darkPanel.add(darkModeText);
			darkPanel.add(darkButton);
			frame.add(darkPanel);			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	/*
	 * This method is invoked when the user selects dark mode. It makes the game frame dark
	 */
	public void makeDark() {
		contentPane.setBackground(Color.lightGray);
	}
	
	/*
	 * This method makes the game frame support the bright mode
	 * @param frame, the display frame where we add this functionality
	 */
	public void addBrightMode(JFrame frame) {
		
		
		try {
			ImageIcon brightImage = new ImageIcon(GameUI.class.getResource("bright.jpg"));
			JButton brightButton = new JButton(brightImage);
			brightButton.addActionListener(e -> makeBright());
			
			JPanel brightPanel = new JPanel();
			
			JLabel brightModeText = new JLabel("Bright Mode");
			brightModeText.setFont(new Font("Georgia" , Font.ITALIC, 10));
			brightModeText.setVerticalAlignment(JLabel.CENTER);
			brightModeText.setHorizontalAlignment(JLabel.CENTER);
			
			brightPanel.setBounds(100,20,70,90);
			brightPanel.add(brightModeText);
			brightPanel.add(brightButton);
			frame.add(brightPanel);	
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	/*
	 * This method is invoked when the user selects bright mode. It makes the game frame bright
	 */
	public void makeBright() {
		contentPane.setBackground(Color.WHITE);
	}
	
	/*
	 * This method makes the game frame support the day mode
	 * @param frame, the display frame where we add this functionality
	 */
	public void addDayMode(JFrame frame) {
		
		
		try {
			ImageIcon dayImage = new ImageIcon(GameUI.class.getResource("day.jpg"));
			JButton dayButton = new JButton(dayImage);
			dayButton.addActionListener(e -> makeDay());
			
			JPanel dayPanel = new JPanel();
			
			JLabel dayModeText = new JLabel("Day Mode");
			dayModeText.setFont(new Font("Georgia" , Font.ITALIC, 10));
			dayModeText.setVerticalAlignment(JLabel.CENTER);
			dayModeText.setHorizontalAlignment(JLabel.CENTER);
			
			dayPanel.setBounds(190,20,70,90);
			dayPanel.add(dayModeText);
			dayPanel.add(dayButton);
			frame.add(dayPanel);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	/*
	 * This method is invoked when the user selects bright mode. It makes the game frame blue i.e. day mode!
	 */
	public void makeDay() {
		contentPane.setBackground(Color.cyan);
	}
	
	/*
	 * This method adds the contrast buttons to the display settings frame
	 */
	public void addContrastOptions(JFrame frame) {
		JButton increaseContrast = new JButton("Increase contrast");
		increaseContrast.addActionListener(e -> increaseContrast());
		JButton decreaseContrast = new JButton("Decrease contrast");
		decreaseContrast.addActionListener(e -> decreaseContrast());
		
		JPanel contrastOptions = new JPanel();
		contrastOptions.add(increaseContrast);
		contrastOptions.add(decreaseContrast);
		contrastOptions.setBounds(80,120,140,100);
		frame.add(contrastOptions);
	}
	
	/*
	 * This method is invoked when the user selects to increase the contrast
	 * NOTE: This functionality is primarily based on the dominos and will be implemented in the future when the dominos become available
	 */
	public void increaseContrast() {
		if (Game.onRawMode()) {
			JOptionPane.showMessageDialog(frame, "Please exit normal model to adjust contrast" , "Contrast Settings", JOptionPane.INFORMATION_MESSAGE);
		}
		else {
		
			for (Player p :playerList) {
				Board b = p.getPlayerBoard();
				b.increaseContrast(currentContrast);
				frame.pack();
			}
			
			Game.increaseContrast(currentContrast);
			
			if (currentContrast == 2) {
				currentContrast =2;
			}
			else {
				currentContrast ++;
			}
			adjustContrastLabel();
		}
	}
	
	/*
	 * This method is invoked when the user selects to decrease the contrast
	 * NOTE: This functionality is primarily based on the dominos and will be implemented in the future when the dominos become available
	 */
	public void decreaseContrast() {
		if (Game.onRawMode()) {
			JOptionPane.showMessageDialog(frame, "Please exit normal model to adjust contrast" , "Contrast Settings", JOptionPane.INFORMATION_MESSAGE);
		}
		else {
			
			for (Player p :playerList) {
				Board b = p.getPlayerBoard();
				b.decreaseContrast(currentContrast);
				frame.pack();
			}
			
			Game.decreaseContrast(currentContrast);
			
	
			
			if (currentContrast == 0) {
				currentContrast =0;
			}
			else {
				currentContrast -=1;
			}
			adjustContrastLabel();
		}
	}
	
	/*
	 * This method returns the current level of contrast
	 * @return currentContrast, an int representing the current level of contrast
	 */
	public static int getCurrentContrastLevel() {
		return currentContrast;
	}
		
	
}



