
import java.io.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.swing.*;
import javax.swing.border.MatteBorder;

/* The Game class conducts the game and allows the game to be played for the said number of players
* @author Mahek Parmar
* 
*/


public class Game implements ActionListener{
	
	protected int dominos_remaining;
	protected int numberOfPlayers;
	protected int currentPlayer;
	
	private static final int TWO_PLAYER_DOMINOS = 24;
	private static final int FOUR_PLAYER_DOMINOS = 48;
	
	protected int row = 9;
	protected int col = 9;
	protected int currentQueue =1;						//initially start with the left queue	
	protected int placingHalf = 0;
	
	protected ArrayList<Player> playerList;
	protected ArrayList <Domino> available_dominos;
	protected ArrayList <Domino> roundDominos1;
	protected ArrayList <Domino> roundDominos2;
	protected ArrayList <Integer> placingOrder; 
	protected ArrayList<Integer> turnKeeper;
	
	protected BufferedReader reader;
	protected Random randgen = new Random();
	
	protected JFrame frame;
	protected JLabel dominosRemainingNumber;
	protected static JPanel roundDominos1Panel;
	protected static JPanel roundDominos2Panel;
	protected JLabel gameInfo;
	protected static JLabel placementMessage;
		
	protected ImageIcon currentLeftTerrainImage;
	protected ImageIcon currentRightTerrainImage;
	protected ImageIcon currentHalfDominoImage;
	protected int currentRightTerrainStars;
	protected String currentRightTerrainName;
	protected int currentLeftTerrainStars;
	protected String currentLeftTerrainName;
	
	protected GridBox leftHalfHolder = new GridBox();
	protected GridBox rightHalfHolder = new GridBox();
	
	protected Domino chosenDomino;						//the chosen domino for placement
	protected GridBox currentHalfDomino;				//the part of the domino currently being placed
	protected static JPanel chosenDominoPanel;			//the panel that houses the domino to place
	
	JButton placeRightButton;
	JButton placeLeftButton; 
	JButton removeDominosButton;
	JButton rawModeButton;
	
	//set of boolean conditions - ensure the smooth coordination btwn different components
	protected Boolean round1PanelIsLocked = false;				//if the first queue is locked
	protected Boolean round2PanelIsLocked = true;				//if the second queue is locked
	protected Boolean removeFromStack = true;				//if true, remove from stack, if false don't
	protected Boolean chooseDomino = false;					//if true, dominos can be chosen
	protected Boolean allowToPlaceDomino = false;			//not used atm - implement
	protected Boolean tilesFlipped = false;					//when true, the tiles in the queues are flipped
	protected Boolean blockPanels = false;					//wehther the queue panels are blocked or not
		
	protected static int pathDistance;
	protected int selectedTerrain;			//when 0 left placed, when 1 right placed
	
	protected String ter = "";			//minor,  just to prevent null errors
	protected int stars = 0;
	
	protected static Boolean rawMode = false;				//0 when normal mode, 1 when rawMode
	
	
	
	public Game(ArrayList<Player> playerList, JFrame frame) throws Exception {
		this.frame = frame;
		this.playerList = playerList;
		numberOfPlayers = playerList.size();
		
		available_dominos = new ArrayList<>();
		roundDominos1 = new ArrayList<>();					//dominos in the first line/queue
		roundDominos2 = new ArrayList<>();					//dominos in the second line/queue
		placingOrder = new ArrayList<>();					//keeps track of the placing order when all dominos are chosen (top domino places first)
		turnKeeper = new ArrayList<>();						//works togethr with placingOrder and keeps tracks of the turns 
		
		chosenDominoPanel = new JPanel();					//panel which contains the domino which is to be placed
		currentHalfDomino = new GridBox();					//the current half of the domino which is to be placed
		placementMessage = new JLabel();					//displayed when an invalid placement occurs
		
		
		//setting up the dominos according to the number of players we have
		if (playerList.size() == 2) {
			setUpDominos(TWO_PLAYER_DOMINOS);
			dominos_remaining = TWO_PLAYER_DOMINOS;
		}
		else {
			setUpDominos(FOUR_PLAYER_DOMINOS);
			dominos_remaining = FOUR_PLAYER_DOMINOS;
		}
		
		//generating a random order for the initial player turns order
		for (int u=0 ; u<numberOfPlayers; u++) {
			int rand = randgen.nextInt(numberOfPlayers)+1;
			while (turnKeeper.contains(rand)) {
				rand = randgen.nextInt(numberOfPlayers)+1;
			}
			turnKeeper.add(rand);
			
		}
		//duplicating the order for the player turns if its a 2 player game
		if (numberOfPlayers ==2) {
			turnKeeper.add(turnKeeper.get(0));
			turnKeeper.add(turnKeeper.get(1));
		}
		

		setUpFrame();
		setUpPlayerBoards();		
		frame.pack();
	}
	
	
	 /* 
	  * This method set's up the frame for the game to be played
	  * 
	  */
	public void setUpFrame() {

		//stack to represent a real world domino stack
		JPanel dominoStack = new JPanel();
		
		JLabel dominosRemainingText = new JLabel("Dominos remaining");
		dominosRemainingNumber = new JLabel("" + dominos_remaining); 
		dominosRemainingText.setFont(new Font("Georgia", Font.BOLD, 20));
		dominosRemainingNumber.setFont(new Font("Georgia", Font.BOLD, 50));
		
		dominosRemainingText.setHorizontalAlignment(JLabel.CENTER);			//label shows how many dominos left
		dominosRemainingText.setVerticalAlignment(JLabel.CENTER);
		dominosRemainingNumber.setVerticalAlignment(JLabel.CENTER);
		dominosRemainingNumber.setHorizontalAlignment(JLabel.CENTER);
		
		dominoStack.setBorder(new MatteBorder(2,2,2,2, Color.black));
		dominoStack.add(dominosRemainingText);
		dominoStack.add(dominosRemainingNumber);
		dominoStack.setBounds(605, 50, 220, 100);
		frame.add(dominoStack);
		
		gameInfo = new JLabel("Click 'Start Game' to start!");
		gameInfo.setBounds(450,740,600,50);
		gameInfo.setFont(new Font("Georgia", Font.BOLD, 25));
		gameInfo.setVerticalAlignment(JLabel.CENTER);
		gameInfo.setHorizontalAlignment(JLabel.CENTER);
		frame.add(gameInfo);
		
		roundDominos1Panel = new JPanel();					//the first line/queue of dominos
		roundDominos1Panel.setBounds (550,400,130,260);
		roundDominos1Panel.setBorder(new MatteBorder(2,2,2,2,Color.black));
		roundDominos1Panel.setLayout(new GridLayout(4,1));
		frame.add(roundDominos1Panel);
		
		roundDominos2Panel = new JPanel();					//the second line/queue of dominos
		roundDominos2Panel.setBounds(750,400,130,260);
		roundDominos2Panel.setBorder(new MatteBorder(2,2,2,2,Color.black));
		roundDominos2Panel.setLayout(new GridLayout(4,1));
		frame.add(roundDominos2Panel);
		
		removeDominosButton = new JButton("Start Game");
		removeDominosButton.setFont(new Font("Georgia", Font.BOLD, 15));
		removeDominosButton.setBorder(new MatteBorder(2,2,2,2,Color.black));
		removeDominosButton.addActionListener(e -> removeDominos());
		removeDominosButton.setBounds(650,180,130,35);
		frame.add(removeDominosButton);
		
		JButton flipAndSortButton = new JButton("Flip + Sort Dominos");
		flipAndSortButton.setFont(new Font("Georgia", Font.BOLD, 15));
		flipAndSortButton.setBorder(new MatteBorder(2,2,2,2,Color.black));
		flipAndSortButton.addActionListener(e -> flipAndSort());
		flipAndSortButton.setBounds(620,700,200,35);
		frame.add(flipAndSortButton);
		
		chosenDominoPanel.setLayout(new GridLayout(1,2));
		chosenDominoPanel.setBounds(675,250,90,43); 
		chosenDominoPanel.setBorder(new MatteBorder(2,2,2,2, Color.black));
		frame.add(chosenDominoPanel);
		
		//buttons to place the left and right part of the domino
		placeLeftButton = new JButton("Place Left Terrain");
		placeLeftButton.setBounds(522,350,170,30);
		placeLeftButton.setBorder(new MatteBorder(2,2,2,2,Color.black));
		placeLeftButton.setFont(new Font("Georgia", Font.BOLD, 13));
		placeLeftButton.addActionListener(e -> placeLeftTerrain());
		frame.add(placeLeftButton);
		
		placeRightButton = new JButton("Place Right Terrain");
		placeRightButton.setBounds(735,350,170,30);
		placeRightButton.setBorder(new MatteBorder(2,2,2,2,Color.black));
		placeRightButton.setFont(new Font("Georgia", Font.BOLD, 13));
		placeRightButton.addActionListener(e -> placeRightTerrain());
		frame.add(placeRightButton);
		
		placementMessage.setBounds(525,210,500,50);
		placementMessage.setFont(new Font("Georgia", Font.BOLD, 20));
		placementMessage.setVerticalAlignment(JLabel.CENTER);
		placementMessage.setHorizontalAlignment(JLabel.CENTER);
		frame.add(placementMessage);
		
		JButton dropButton = new JButton("Drop?");
		dropButton.setBounds(650,180,130,35);
		dropButton.setBorder(new MatteBorder(2,2,2,2,Color.black));
		dropButton.setFont(new Font("Georgia", Font.BOLD, 15));
		dropButton.addActionListener(e -> dropDomino());
		frame.add(dropButton);
		
		JLabel q1Label = new JLabel("Queue 1");
		q1Label.setFont(new Font("Georgia", Font.BOLD, 18));
		q1Label.setBounds(580,650,90,40);
		frame.add(q1Label);
		JLabel q2Label = new JLabel("Queue 2");
		q2Label.setFont(new Font("Georgia", Font.BOLD, 18));
		q2Label.setBounds(780,650,90,40);
		frame.add(q2Label);
		
		rawModeButton = new JButton("Enter Raw mode");
		rawModeButton.setFont(new Font("Georgia", Font.BOLD, 15));
		rawModeButton.setBorder(new MatteBorder(2,2,2,2,Color.black));
		rawModeButton.setBounds(640,10,150,30);
		rawModeButton.addActionListener(e-> changeToRawMode());
		frame.add(rawModeButton);
		
		
	}
	
	/*
	 * This method retrieves the individual grids of the board and adds action listeners to them
	 */
	public void setUpPlayerBoards() {
		for (Player p: playerList) {
			Board pBoard = p.getPlayerBoard();
			GridBox [][] grids = pBoard.getBoardGrids();
			for (int a=0 ; a<row ; a++) {
				for (int b=0 ; b<col ; b++) {
					grids[a][b].addActionListener(this);
				}
			}
			}
		}

	/*
	 * This function set's up all the Domino's of our game
	 * 
	 */
	public void setUpDominos(int numOfDominos) throws Exception {
		//the details pertaining to every domino are stores in the CSV file DominoDetails.csv in resouces.
		
			String line ="";
			//we parse this file and create the corresponding dominos with their respective attributes
					try {						
						InputStreamReader isr = new InputStreamReader(getClass().getResourceAsStream("/DominoDetails.csv"));
						reader = new BufferedReader(isr);
						line = reader.readLine();//get rid of the headers
						int i = 0;
		
						while ((line = reader.readLine()) != null && (i<numOfDominos)) {
							String [] dominoDetails = line.split(",");
							int number = Integer.parseInt(dominoDetails[0]);
							String frontLocation = dominoDetails[1];
							String rearLocation = dominoDetails[2]; 
							String leftTerrain = dominoDetails[3]; 
							String rightTerrain = dominoDetails[4];
							int leftTerrainStars = Integer.parseInt(dominoDetails[5]);
							int rightTerrainStars = Integer.parseInt(dominoDetails[6]);
							
							
							
							
							Domino newDomino = new Domino(number, rearLocation, frontLocation, leftTerrain, rightTerrain, leftTerrainStars, rightTerrainStars);
							newDomino.addActionListener(this);
							
										//adding all the dominos to the available_dominos arraylist
						
							available_dominos.add(newDomino);
					}
						
						
						
				}
				catch (Exception e){
					System.out.println("exp");
				}
				finally {
					try {
						if (reader!= null) {
						reader.close();}
					} 
					catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
		
				
	}
	
	/*
	 * This method removes dominos from the available ones
	 * 
	 */
	public void removeDominos() {
		removeDominosButton.setVisible(false);
		if (removeFromStack && (dominos_remaining >=4)) {
			
			for (int i = 0 ; i < 4 ; i++) {
				//for the first line/queue
				if (roundDominos1Panel.getComponentCount() <4) {
					//randomly remove dominos from the ones that available
					int indexToRemove = getRandomDominoNumber();
					Domino tempDomino = available_dominos.get(indexToRemove);
					roundDominos1.add(tempDomino);							//dominos added to the first panel, are stored in the roundDominos1 arraylist
					roundDominos1Panel.add(tempDomino);
					available_dominos.remove(indexToRemove);				//the domino just drawn from the stack if removed from those that are available in the stack
					dominos_remaining -=1;
					currentQueue = 2;
				}
				//for the second line/queue
				if (roundDominos2Panel.getComponentCount() <4) {
					int indexToRemove = getRandomDominoNumber();
					Domino tempDomino = available_dominos.get(indexToRemove);
					
					roundDominos2.add(tempDomino);
					roundDominos2Panel.add(tempDomino);
					available_dominos.remove(indexToRemove);
					dominos_remaining -=1;
					currentQueue = 1;
				}
			}
			dominosRemainingNumber.setText("" +dominos_remaining);
			gameInfo.setText("Flip Dominos to Begin Round!");
			removeFromStack = false;				//prevents further removal of dominos from the stack
			blockPanels = true;						//panels are blocked for placement or selection until the dominos are sorted and flipped
			tilesFlipped = false;
			chooseDomino = false;
			
		}
		//for the case when the game end
		else if ((roundDominos1Panel.getComponentCount()==0) && (roundDominos2Panel.getComponentCount()==0) && (dominos_remaining ==0)) {
			gameInfo.setText("Thanks for playing!");
			calculateScores();
		}
		//for the case when theres no dominos left to be drawn out and theres only one queue
		else if ((roundDominos1Panel.getComponentCount() == 4) || (roundDominos2Panel.getComponentCount()==4)){
			currentPlayer = turnKeeper.remove(0);
			gameInfo.setText("" + getCurrentPlayerName()+ " choose your domino (Queue " + currentQueue +")");
		}
	

	}
	
	/*
	 * This method flips every domino once it is removed form the stack and placed in the queues
	 */
	public void flipAndSort() {
		//only works once dominos are removed from the stack
		
		if (!(removeFromStack) && !(tilesFlipped))  {
			
			roundDominos1Panel.removeAll();
			roundDominos2Panel.removeAll();
			//sorts the dominos in each queue using the sortDomino() function
			//sorts into ascending order 
			roundDominos1 = sortDomino(roundDominos1);
			roundDominos2 = sortDomino(roundDominos2);
			//for the first line/queue
			if (roundDominos1.size() >0) {
				for (Domino d: roundDominos1) {
					roundDominos1Panel.add(d);
					d.flip();					//flips side to show the rear side (one with the terrains and stars)
				}
			}
			//for the second line/queue
			if (roundDominos2.size() >0) {
				for (Domino d: roundDominos2) {
					roundDominos2Panel.add(d);
					d.flip();
				}
			}
			frame.pack();
			chooseDomino = true;						//now we allow dominos in the queues/lines to be chosen
			tilesFlipped = true;
			blockPanels = false;
			currentPlayer = turnKeeper.remove(0);

			showDominoDetails();
			gameInfo.setText("" + getCurrentPlayerName() + " choose your Domino (Queue " + currentQueue + ")" );
		}
	}
	
	/*
	 * A helper method that helps generate a random number from 0 to the number of avialable dominos
	 * @return temp, the random domino number
	 */
	public int getRandomDominoNumber() {
		
			int temp = randgen.nextInt(available_dominos.size());
			return temp;
	
	
	}
	
	/*
	 * A method that sorts an arraylist of Domino based on their numbers. It sorts them in 
	 * ascending order, smallest domino number to largest
	 * @param queue, an ArrayList of Dominos to be sorted
	 * @return queue, the sorted ArrayList of Dominos
	 */
	public ArrayList<Domino> sortDomino(ArrayList<Domino> queue) {
		if (queue.size() > 0) {
			Collections.sort(queue, new Comparator<Domino>()
					{
						public int compare(Domino d1, Domino d2) {
							return Integer.valueOf(d1.getDominoNumber()).compareTo(d2.getDominoNumber());
						}
					});	
		}
		return queue;
	}
		
	/*
	 * This method provides the small texts representing domino terrains and stars incase for vision accessability
	 */
	public void showDominoDetails() {
		if (roundDominos1Panel.getComponentCount() > 0) {
			for (int i =0; i< roundDominos1Panel.getComponentCount() ; i++ ) {
				if (roundDominos1Panel.getComponent(i) instanceof Domino){
					frame.add((((Domino) roundDominos1Panel.getComponent(i)).showRightDominoDetails(1)));
					frame.add((((Domino) roundDominos1Panel.getComponent(i)).showLeftDominoDetails(1)));
				}
			}
		}	
		if (roundDominos2Panel.getComponentCount()>0) {
			for (int i =0; i< roundDominos2Panel.getComponentCount() ; i++ ) {		
				if (roundDominos2Panel.getComponent(i) instanceof Domino){
					frame.add((((Domino) roundDominos2Panel.getComponent(i)).showRightDominoDetails(2)));
					frame.add((((Domino) roundDominos2Panel.getComponent(i)).showLeftDominoDetails(2)));
				}
			}
		}
		frame.pack();
	}

	/*
	 * This method handles the actions performed for the grids of the board and for the dominos
	 * @param aevt, the action event
	 * 
	 */
	public void actionPerformed(ActionEvent aevt) {
		Object source = aevt.getSource();
		//if a Domino object is clicked
		
		
		
		if (source instanceof Domino) {
			Domino clickedDomino = ((Domino)source);
			
			//blockPanels => is true when a domino is to be placed, when dominos are getting selected it will be false
			//tilesFlipped => when the tiles are sorted and flipped, only clicking dominos resembles functionalities
			if (!blockPanels && tilesFlipped){
				
				if (roundDominos1.contains(clickedDomino) && !(round1PanelIsLocked)) {
					//chooseDomino => will be true once tiles have been flipped
					if (source instanceof Domino && chooseDomino) {
						//if the clicked domino is unchosen, make the chosen giving the currentplayer attributes
						if (clickedDomino.isUnchosen()){
							
							clickedDomino.chosen(currentPlayer, getCurrentPlayerName());
							frame.add(clickedDomino.updateLabel(1, getCurrentPlayerColor()));
							frame.pack();
		
							clickedDomino.setBorder(new MatteBorder(4,4,4,4, getCurrentPlayerColor()));
							//once a domino is chosen, update the current player
							try{currentPlayer = turnKeeper.remove(0);} catch (Exception e) {};
						}		
					}
					
					if (!allowToPlaceDomino) {
					//reselecting a chosen domino will do nothing
						gameInfo.setText("" + getCurrentPlayerName()+ " choose your Domino (Queue " + currentQueue + ")" );
					}
					
					// at this point all dominos in round1panel are chosen, now we want to place them
					if (allChosen(roundDominos1)) {
						//player whose chosen domino is top of the queue/line should place it
						//we get this info using getPlacingOrder function
						getPlacingOrder(roundDominos1, roundDominos1Panel);
						currentPlayer = placingOrder.get(0);
						gameInfo.setText("" + getCurrentPlayerName() + " place your Domino (Queue " + currentQueue + ")");
						//allow the domino which is top of the queue to be placed
						if (    (  clickedDomino.getOwnedByNumber() == placingOrder.get(0)  ) &&   (   clickedDomino.getDominoNumber() == ((Domino) roundDominos1Panel.getComponent(0)).getDominoNumber() )  ) {
							//allow that domino to be placed
							((Domino)source).allowToBePlaced();
						}
					}
					
					if (clickedDomino.canBePlaced()) {
						placingOrder.remove(0);			//remove from placing order
						playerList.get(currentPlayer-1).getPlayerBoard().unblock();		//unblock that players board so dominos can be placed
						turnKeeper.add(currentPlayer);
						//place the domino 
						placeDomino(clickedDomino, roundDominos1Panel, roundDominos1);
												
					}
					
				}				//for the second queue
				else {
					
					if (roundDominos2.contains(clickedDomino) && !(round2PanelIsLocked)) {
						//chooseDomino => will be true once tiles have been flipped
						if (source instanceof Domino && chooseDomino) {
							//if the clicked domino is unchosen, make the chosen giving the currentplayer attributes
							if (clickedDomino.isUnchosen()){
								
								clickedDomino.chosen(currentPlayer, getCurrentPlayerName());
								frame.add(clickedDomino.updateLabel(2, getCurrentPlayerColor()));
								frame.pack();
								clickedDomino.setBorder(new MatteBorder(4,4,4,4, getCurrentPlayerColor()));
								//once a domino is chosen, update the current player
								try{currentPlayer = turnKeeper.remove(0);} catch (Exception e) {};
							}		
						}
						//reselecting a chosen domino will do nothing
						if (!allowToPlaceDomino) {
							gameInfo.setText("" + getCurrentPlayerName()+ " choose your Domino (Queue " + currentQueue + ")");
						}
						
						// at this point all dominos in round1panel are chosen, now we want to place them
						//turnkeeper will be empty at this point
						if (allChosen(roundDominos2)) {
							//player whose chosen domino is top of the queue/line should place it
							//we get this info using getPlacingOrder function
							getPlacingOrder(roundDominos2, roundDominos2Panel);
							currentPlayer = placingOrder.get(0);
							gameInfo.setText("" + getCurrentPlayerName() + " place your Domino (Queue " + currentQueue + ")");
							if (    ( clickedDomino.getOwnedByNumber() == placingOrder.get(0)  ) &&   (   clickedDomino.getDominoNumber() == ((Domino) roundDominos2Panel.getComponent(0)).getDominoNumber() )  ) {
								//allow that domino to be placed
								clickedDomino.allowToBePlaced();
							}
						}
						
						if (clickedDomino.canBePlaced()) {
							placingOrder.remove(0);			//remove from placing order
							playerList.get(currentPlayer-1).getPlayerBoard().unblock();		//unblock that players board so dominos can be placed
							//place the domino 
							turnKeeper.add(currentPlayer);
							placeDomino(clickedDomino, roundDominos2Panel, roundDominos2);
													
						}
					}
				}
			}
		}
		//the individual grid of the board is clicked when placing a domino
		else if (source instanceof GridBox) {
						
			//when the placing half is 0 we have several options to place that first part of the domino
			//when the palcing half is 1, we have at most 3 positions to place the second part of the domino,
			//as the second part must be placed together with the first part
			GridBox clickedGridBox = ((GridBox)source);
			
			int xPos = ((GridBox)source).getXIndex();
			int yPos = ((GridBox)source).getYIndex();
			
			Board currentBoard = getCurrentPlayerBoard();
			//when placing the first half of a domino
			if ( allowToPlaceDomino && clickedGridBox.isAvailable()  && (clickedGridBox.getBoardNumber() == currentPlayer && (placingHalf ==0))){
			//checks if the placement is valid (terran matches) and check if there's space for the second half to be placed
				if (currentBoard.validPlacement(xPos, yPos, getChosenHalfDominoTerrain()) && currentBoard.hasAdjacentPosition(xPos, yPos) ) {
					//pass on the half domino attributes to the GridBox
					giveGridAttributes(clickedGridBox, selectedTerrain);
					//different course of action to take depending on whether Raw mode is selected or not
					if (!rawMode) {
						clickedGridBox.setIcon(currentHalfDominoImage);	
						clickedGridBox.setBorder(null);
					}
					else {
						clickedGridBox.addRawTerrain();
					}
					//checks bounds for the board, implemented to restrict a board/kingdom to a 5*5
					currentBoard.boundsChecker(xPos, yPos);
					
					placementMessage.setText("");
					
					//make that individual gridbox not available and occupied so it cannot be selected again	
					clickedGridBox.setNotAvailable();
					clickedGridBox.makeOccupied();
					
					//once the first part of the domino is placed, we need to adjust the neighbours for the 2nd part of the domino to be placed
					currentBoard.adjustNeighbours(xPos, yPos);
					
					hidePlacementButtons();
					
					chosenDominoPanel.setBounds(690,250,43,43); 
					chosenDominoPanel.remove(currentHalfDomino);			//remove from the panel which displays the domino to place
					currentHalfDomino.removeAll();
					currentHalfDomino = null;								//depracating for the next round		
					placingHalf = (placingHalf +1) %2;					//placing half =1, which means we place the second part now
					allowToPlaceDomino = false;
					frame.pack();
				}	
			}
			//when placing the second part of the domino
			else if ( allowToPlaceDomino && clickedGridBox.isAvailable()  && ((clickedGridBox.getBoardNumber() == currentPlayer) && (placingHalf ==1)) && clickedGridBox.isAdjacent()){
				giveGridAttributes(clickedGridBox, selectedTerrain);
				
				if (!rawMode) {
					clickedGridBox.setIcon(currentHalfDominoImage);	
					clickedGridBox.setBorder(null);
				}
				else {
					clickedGridBox.addRawTerrain();
				}
				currentBoard.boundsChecker(xPos, yPos);
			
				//make that individual gridbox not available and occupied so it cannot be selected again
				clickedGridBox.setNotAvailable();
				clickedGridBox.makeOccupied();
				
				placementMessage.setText("");
				currentBoard.adjustNeighbours(xPos, yPos);
				//on placing the second part of the tiles, we adjust the neighbours for placing further tiles
				
				
				hidePlacementButtons();
				
				chosenDominoPanel.setBounds(675,250,90,43); 
				chosenDominoPanel.remove(currentHalfDomino);
				currentHalfDomino.removeAll();
				currentHalfDomino = null;
				
				currentBoard.block();
				//once both parts of the domino are places, we now block the placing players board
				
				placingHalf = (placingHalf +1) %2;
				allowToPlaceDomino = false;
				blockPanels = false;
				placeLeftButton.setVisible(true);				//make both buttons appear again for next round
				placeRightButton.setVisible(true);
				
				//doesnt matter for last player as it will be replaced by flip!
				try{currentPlayer = placingOrder.get(0);} catch (Exception e) {};
				gameInfo.setText("" + getCurrentPlayerName()+ " place your Domino (Queue " + currentQueue + ")");
				currentBoard.removeAllAdjacencies();
				prepareForNextRound();
				
				frame.pack();
				
			}
		}
		
	}
	
	/*
	 * This function takes the topmost domino from the queue, splits it into 2 parts and displays it 
	 * @param d, the Domino to place
	 * @param panel, the JPanel were the domino was 
	 * @param roundDominos, the arraylist storing dominos of that line/queue
	 */
	public void placeDomino(Domino d, JPanel panel, ArrayList<Domino> roundDominos) {
		chosenDomino = d;
	
		currentLeftTerrainImage = d.getLeftTerrainImage(GameUI.getCurrentContrastLevel());
	
		currentRightTerrainImage = d.getRightTerrainImage(GameUI.getCurrentContrastLevel());
		
		leftHalfHolder.setIcon(currentLeftTerrainImage);
		rightHalfHolder.setIcon(currentRightTerrainImage);
		
		chosenDominoPanel.add(leftHalfHolder);
		chosenDominoPanel.add(rightHalfHolder);
		d.hideLabel();
		frame.add(d.showRightTerrainLabelOnChosenPanel());
		frame.add(d.showLeftTerrainLabelOnChosenPanel());
		panel.remove(d);									//remove the domino from the panel where it initially way
		
		
		//remove from that list that contains all the dominos of that queue
		for (int q=0 ; q<roundDominos.size() ; q++) {
			if (roundDominos.get(q) == d) {
				roundDominos.remove(q);
				break;
			}
		}
		for (int k =0 ; k<roundDominos.size(); k++) {
			if (round2PanelIsLocked) {
				roundDominos.get(k).moveLeftDominoDetailsUp(1);
				roundDominos.get(k).moveRightDominoDetailsUp(1);
				roundDominos.get(k).moveLabelUp(1);
			}
			else {
				roundDominos.get(k).moveLeftDominoDetailsUp(2);
				roundDominos.get(k).moveRightDominoDetailsUp(2);
				roundDominos.get(k).moveLabelUp(2);
			}
		}
		//now that we are placing a domino, block the queues 
		blockPanels = true;
		frame.pack();
		
	}
	
	/*
	 * This method gives the playernumber order in which dominos are to be placed
	 * The player whose domino is top of the queue should place the domino first
	 * @ param queue, the arraylist of dominos of the current fully chosen queue
	 * @ param panel, the panel which contains the chosen dominos
	 * @ return placingOrder, an arrayList defining which player places their domino first
	 */
	public ArrayList<Integer> getPlacingOrder(ArrayList <Domino> queue, JPanel panel) {
		placingOrder = new ArrayList<>();
		
		for (int y = 0 ; y< queue.size() ; y++) {
			placingOrder.add(((Domino) panel.getComponent(y)).getOwnedByNumber());
			
			
		}
		return placingOrder;
		
	}

	/*
	 * This function takes an arrayList of Domino can checks if all the dominos are chosen or not
	 * @return Boolean, true if all dominos are chosen, else false
	 */
	public Boolean allChosen(ArrayList<Domino> queue) {
		int z = 0;
		for (Domino d: queue) {
			if (!d.isUnchosen()) {
				z++;
			}
		}
		if (z==queue.size()) {
			return true;					//all dominos in the queue are chosen
		}
		else {
			return false;						//all dominos are not chosen
		}
	}
	
	/*
	 * This function allows the user to drop/discard a domino once they click the 'Drop?' button
	 * It would onyl drop a domino if neither half of a domino is placed
	 */
	public void dropDomino() {
		//placing half has to be 0 to drop a domino, so it cannot be dropped once one part of the domino has been placed
		if (   (   (chosenDominoPanel.getComponentCount()) !=0) && placingHalf ==0  && blockPanels) {			
			//housekeeping
			placeRightButton.setVisible(true);
			placeRightButton.setBorder(null);
			placeLeftButton.setVisible(true);
			placeLeftButton.setBorder(null);
			chosenDomino.hideLeftTerrainLabelOnChosenPanel();
			chosenDomino.hideRightTerrainLabelOnChosenPanel();
			chosenDominoPanel.removeAll();			//remove from the panel which displays the domino to place

			try{currentHalfDomino.removeAll();}catch (Exception e) {}
			currentHalfDomino = null;								
			
			allowToPlaceDomino = false;
			
			//the player who drops a domino looses their turn, so we block their board
			playerList.get(currentPlayer-1).getPlayerBoard().block();
			
			//allows for the next domino to be placed or chosen
			blockPanels = false;

			//the case where the last placement from the queue is to be dropped, prevents the null exception
			//regardless of whether its dropped or not, once the last domino from the queue is flip the new queue
			try{
				currentPlayer = placingOrder.get(0);
			} 
			catch (Exception e) {};
				
			gameInfo.setText("" + getCurrentPlayerName()+ " place your Domino (Queue " + currentQueue + ")");
			prepareForNextRound();
			frame.pack();
			
		}
	}
	
	/*
	 * This method sets-up/prepares the game for the next round
	 */
	public void prepareForNextRound() {
		//if the first queue is empty, we lock it and make queue 2 our current queue and unlock it, we then remove dominos
		if(roundDominos1Panel.getComponentCount()==0) {
			removeFromStack = true;
			currentQueue = 2;
			round1PanelIsLocked = true;
			round2PanelIsLocked = false;
			removeDominos();
		}
		//if the 2nd queue is empty, we lock it and make queue 1 our current queue and unlock it, we then remove dominos
		else if (roundDominos2Panel.getComponentCount() ==0){
			removeFromStack = true;
			currentQueue = 1;
			round2PanelIsLocked = true;
			round1PanelIsLocked = false;
			removeDominos();
		}
		
			}
	
	/*
	 * This mmethod returns the terrain name of the chosen half domino
	 * @return String name of the terrain of the current half domino
	 */
	public String getChosenHalfDominoTerrain() {
		if (selectedTerrain == 0) {
			return chosenDomino.getLeftTerrainName();
		}
		else {
			return chosenDomino.getRightTerrainName();
		}
	}
	
	/*
	 * This method gives attributes to the GridBox where a domino is placed
	 * @param grid, the GridBox object where a domino is successfully palced
	 * @param selectedTerrain, represents which part of the domino is palced, 0 when left, 1 when right
	 * 
	 */
	public void giveGridAttributes(GridBox grid, int selectedTerrain) {
		if (selectedTerrain == 0) {
			grid.setStars(chosenDomino.getLeftTerrainStars());
			grid.setTerrain(chosenDomino.getLeftTerrainName());
			grid.setCurrentFileName(chosenDomino.getLeftTerrainFileName());
		}
		else {
			grid.setStars(chosenDomino.getRightTerrainStars());
			grid.setTerrain(chosenDomino.getRightTerrainName());
			grid.setCurrentFileName(chosenDomino.getRightTerrainFileName());
		}
		
	}
	
	/*
	 * ActionListener method for the placeLeftButton
	 * This method allows the user to be able to place the left part of the domino
	 * 
	 */
	public void placeLeftTerrain() {
		if (blockPanels) {	//when the panels are blocked, this means dominos are being placed
			selectedTerrain = 0;
			allowToPlaceDomino = true;					//allows to click the grid of the board
			currentHalfDomino = leftHalfHolder;				//when we want to place the left part, currentHalfDomino is set to it
			currentHalfDominoImage = currentLeftTerrainImage;
			highlightPlacementButtons(placeLeftButton, placeRightButton);
		}
	}
	
	/*
	 * ActionListener method for the placeRightButton
	 * This method allows the user to be able to place the right part of the domino
	 * 
	 */
	public void placeRightTerrain() {
		if (blockPanels) {	//when the panels are blocked, this means dominos are being placed
			selectedTerrain = 1;
			allowToPlaceDomino = true;						//allows to click the grid of the board
			currentHalfDomino = rightHalfHolder;			//when we want to place the right part, currentHalfDomino is set to it
			currentHalfDominoImage = currentRightTerrainImage;
			highlightPlacementButtons(placeRightButton, placeLeftButton);

		}
	}
	
	/*
	 * This method highlights the placement buttons increasing clarity
	 * @param b1, b2, the buttons to highlight
	 */
	public void highlightPlacementButtons(JButton b1, JButton b2) {
		b1.setBorder(new MatteBorder(2,2,2,2,getCurrentPlayerColor()));
		b2.setBorder(null);
	}
	
	/*
	 * This method hides the placement buttons when one half of a domino is placed
	 */
	public void hidePlacementButtons() {
		if (selectedTerrain == 1) {
			chosenDomino.hideRightTerrainLabelOnChosenPanel();
			placeRightButton.setVisible(false);
			placeRightButton.setBorder(null);
		}
		else {
			chosenDomino.hideLeftTerrainLabelOnChosenPanel();
			placeLeftButton.setVisible(false);
			placeLeftButton.setBorder(null);
		}
	}
		
	/*
	 * This method calculates the player's scores and sorts the player list based on the scores in DESC
	 */
	public void calculateScores() {
		//for every player
		for (Player p:playerList) {
			GridBox[][] grids = p.getBoardGrids();
			int starCount =0;
			for (int i=0 ; i<row ; i++) {
				for (int j=0 ; j<col ; j++) {
					//if the current GridBox is already chosen, is not already counted and is not out of bounds,
					//we get the number of stars in the path it forms and also increment the pathDistance whenver we traverse a path
					pathDistance =1;
					if (     (!(grids[i][j].isOutOfBounds())) &&     (!(grids[i][j].isCounted())) && (grids[i][j].isOccupied())     ) {				//if not out of bound and not already counted
						int starsInPath = getPathStars(grids[i][j], grids);
						starCount += starsInPath;
						//the score of that path is added to the players total score. This is done for the whole board
						p.addToPlayerScore((starsInPath * pathDistance));
					}		
				}
			}
			p.setPlayerStars(starCount);
			starCount =0;
		}
		//sorting the players in the playerlist based on their scores in DESC
		Collections.sort(playerList, new Comparator<Player>()
		{
			public int compare(Player p1, Player p2) {
				if (p2.getPlayerScore() == p1.getPlayerScore()) {
					return Integer.valueOf(p2.getPlayerStars()).compareTo(p1.getPlayerStars());
				}
				else {
					return Integer.valueOf(p2.getPlayerScore()).compareTo(p1.getPlayerScore());
				}
			}
		});	
		//calls the end game frame
		EndGame end = new EndGame(frame, playerList);
		
	}
	
	/*
	 * This method calcualtes the number of stars in a path that a given GridBox forms
	 * @param current, the GridBox where we want to start building/tracing our path 
	 * @param grids, the grids in the player's board
	 */
	public static int getPathStars(GridBox current, GridBox[][] grids) {
			
		GridBox upper = null;				
		GridBox left = null;
		GridBox right = null;
		GridBox down = null;
		
		int xPos = current.getXIndex();
		int yPos = current.getYIndex();
		//getting the up, left, right and down GridBox's relative to current
		try {
			upper = grids[xPos-1][yPos];	
		}catch (Exception e) {};
		
		try {
			left = grids[xPos][yPos-1];
		}catch (Exception e) {};
		
		try {
			right = grids[xPos][yPos+1];
		}catch (Exception e) {};
		
		try {
			down = grids[xPos+1][yPos];
		}catch (Exception e) {};
		
		current.setCounted();				//setting current as already counted for scoring 
		
		int pathStars = current.getStars();
		
		//using recursion to build and calcualte the number of stars in the path and also incrementing the path distance in doing so
		if (upper != null && !(upper.isOutOfBounds()) && upper.isOccupied()) {
			if (!(upper.isCounted()) && current.getTerrain().equals(upper.getTerrain())) {
				pathDistance +=1;
				current = upper;
				pathStars += getPathStars(upper, grids);
			}
		}
		if (left!= null && !(left.isOutOfBounds()) && left.isOccupied()) {
			if (!(left.isCounted()) && current.getTerrain().equals(left.getTerrain())) {
				pathDistance +=1;
				current = left;
				pathStars += getPathStars(left, grids);
			}
		}
		if (right != null && !(right.isOutOfBounds()) && right.isOccupied()) {
			if (!(right.isCounted()) && current.getTerrain().equals(right.getTerrain())) {
				pathDistance +=1;
				current = right;
				pathStars += getPathStars(right, grids);
			}
		}
		if (down!= null && !(down.isOutOfBounds()) && down.isOccupied()) {
			if (!(down.isCounted()) && current.getTerrain().equals(down.getTerrain())) {
				pathDistance +=1;
				current = down;
				pathStars += getPathStars(down, grids);
			}
		}
		return pathStars;
		
		}
	
	/*
	

	/*
	 * Accessor method that helps identify if were on raw mode or not
	 * @return rawMode, a Boolean when true represents were on raw mode
	 */
	public static Boolean onRawMode() {
		return rawMode;
	}
	
	/*
	 * This method allows us to change to and from raw mode
	 */
	public void changeToRawMode() {
		if (!rawMode) {
			for (Player p : playerList) {
				((Board) p.getPlayerBoard()).changeToRawMode();
			}
			rawMode = true;
			rawModeButton.setText("Exit Raw Mode");
		}
		else {
			for (Player p : playerList) {
				((Board) p.getPlayerBoard()).exitRawMode();
			}
			rawMode = false;
			rawModeButton.setText("Enter Raw Mode");	
		}
		frame.pack();
	}
	

	//CONTRAST SETTINGS METHODS
	/*
	 * This method increases the contrast on the chosen domino panel
	 * @param currentContrast, an int representing the current contrast level
	 */
	public static void increaseContrastOnChosenDominoPanel(int currentContrast) {
		int count = chosenDominoPanel.getComponentCount();
		
		for (int t=0 ; t<count ; t++) {
			((GridBox) chosenDominoPanel.getComponent(t)).increaseContrast(currentContrast);
			
		}
		
	}
	
	/*
	 * This method decreases the contrast on the chosen domino panel
	 * @param currentContrast, an int representing the current contrast level
	 */
	public static void decreaseContrastOnChosenDominoPanel(int currentContrast) {
		int count = chosenDominoPanel.getComponentCount();
		
		for (int t=0 ; t<count ; t++) {
			((GridBox) chosenDominoPanel.getComponent(t)).decreaseContrast(currentContrast);
			
		}
		
	}
	
	/*
	 * This method increases the contrast on the domino queues
	 * @param currentContrast, an int representing the current contrast level
	 */
	public static void increaseContrastOnQueue(int currentContrast) {
		for (int i=0; i< Game.roundDominos1Panel.getComponentCount() ; i++) {
			
			if (Game.roundDominos1Panel.getComponent(i) instanceof Domino) {
				
				((Domino)Game.roundDominos1Panel.getComponent(i)).increaseContrast(currentContrast);
			}
		}
		for (int i=0; i< Game.roundDominos2Panel.getComponentCount() ; i++) {
			if (Game.roundDominos2Panel.getComponent(i) instanceof Domino) {
				((Domino)Game.roundDominos2Panel.getComponent(i)).increaseContrast(currentContrast);
			}
		}
			
	}
	
	/*
	 * This method decreases the contrast on the domino queues
	 * @param currentContrast, an int representing the current contrast level
	 */
	public static void decreaseContrastOnQueue(int currentContrast) {
		for (int i=0; i< Game.roundDominos1Panel.getComponentCount() ; i++) {
			
			if (Game.roundDominos1Panel.getComponent(i) instanceof Domino) {
			
				((Domino)Game.roundDominos1Panel.getComponent(i)).decreaseContrast(currentContrast);
			}
		}
		for (int i=0; i< Game.roundDominos2Panel.getComponentCount() ; i++) {
			if (Game.roundDominos2Panel.getComponent(i) instanceof Domino) {
				((Domino)Game.roundDominos2Panel.getComponent(i)).decreaseContrast(currentContrast);
			}
		}
			
	}
	
	/*
	 * A static method when called increases the contrast on the domino queus and the chosen domino panel 
	 * @param currentContrast, an int representing the current contrast level
	 */
	public static void increaseContrast(int currentContrast) {
		increaseContrastOnQueue(currentContrast);
		increaseContrastOnChosenDominoPanel(currentContrast);
	}
	
	/*
	 * A static method when called decreases the contrast on the domino queus and the chosen domino panel 
	 * @param currentContrast, an int representing the current contrast level
	 */
	public static void decreaseContrast(int currentContrast) {
		decreaseContrastOnQueue(currentContrast);
		decreaseContrastOnChosenDominoPanel(currentContrast);
	}

	
	//ADDITIONAL METHODS FOR PROTECTED VARIATIONS///
	
	/*
	 * Accessor method that returns the name of the current player
	 */
	private String getCurrentPlayerName() {
		return playerList.get(currentPlayer-1).getPlayerName();
	}
	
	/*
	 * This method returns the current Player object
	 */
	private Player getCurrentPlayer() {
		return playerList.get(currentPlayer-1);
	}
	
	/*
	 * Accesor method that returns the current players color of choice
	 */
	private Color getCurrentPlayerColor() {
		return getCurrentPlayer().getColor();
	}
	
	/*
	 * Accessor method that returns the current players Board object
	 */
	private Board getCurrentPlayerBoard() {
		return getCurrentPlayer().getPlayerBoard();
	}
		
}
