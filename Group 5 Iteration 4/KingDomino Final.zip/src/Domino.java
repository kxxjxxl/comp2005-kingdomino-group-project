import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;

import javax.swing.*;
import javax.swing.border.MatteBorder;


/*
 * This class represents a Domino object
 * @author Mahek Parmar
 * 
 */
public class Domino extends JButton {
	//all these are the details pertaining to a domino
	protected String leftTerrain;
	protected String rightTerrain;
	protected int number;
	protected int leftTerrainStars;
	protected int rightTerrainStars;
	protected String frontFileLocation;
	protected String rearFileLocation;
	
	//additional fields to help in gameplay
	protected Boolean chosen;
	protected int ownedBy;
	protected String ownedByName;
	protected Boolean canBePlaced ;
	protected Boolean flipped;
	protected JLabel label;
	
	protected JLabel leftTerrainLabel;
	protected JLabel rightTerrainLabel;
	
	protected String leftFileName;
	protected String rightFileName;
	
	
	
	public Domino(int number, String rearFileLocation, String frontFileLocation, String leftTerrain, String rightTerrain, int leftTerrainStars, int rightTerrainStars) {
		super();
		this.number = number;
		this.frontFileLocation = frontFileLocation;
		this.rearFileLocation = rearFileLocation;

		this.leftTerrain = leftTerrain;
		this.rightTerrain = rightTerrain;

		this.leftTerrainStars = leftTerrainStars;
		this.rightTerrainStars = rightTerrainStars;
		
		chosen = false;					//whether the domino is chosen or not
		canBePlaced = false;			//if it can be placed or not
		flipped = false;					//initially every domino is not flipped
		ownedByName ="";				//the player who selects the domino
		
		label = new JLabel();
		leftTerrainLabel = new JLabel();
		rightTerrainLabel = new JLabel();
		setUp();
	}
	
	
	
	/*
	 * Accesor method that provides the dominos left terrain name
	 * @return leftTerrain, String representing the dominos left terrain name
	 */
	public String getLeftTerrainName() {
		return leftTerrain;
	}
	
	/*
	 * Accesor method that provides the dominos right terrain name
	 * @return rightTerrain, String representing the dominos right terrain name
	 */
	public String getRightTerrainName() {
		return rightTerrain;
	}
	
	/*
	 * Accesor method that returns the number of stars/crowns in the dominos left terrain
	 * @return leftTerrainStars, an int representing the number of stars/crowns in the dominos left terrain 
	 */
	public int getLeftTerrainStars() {
			return leftTerrainStars;
	}
	
	/*
	 * Accesor method that returns the number of stars/crowns in the dominos right terrain
	 * @return rightTerrainStars, an int representing the number of stars/crowns in the dominos right terrain 
	 */
	public int getRightTerrainStars() {
			return rightTerrainStars;
		}
		
	/*
	 * This method returns the image representing the dominos left terrain
	 * @param currentContrast, an int representing the current constrast level so the images account for it
	 */
	public ImageIcon getLeftTerrainImage(int currentContrast) {
			leftFileName = "";
			if (currentContrast == 0) {
				String domNum = String.format("%02d", number);
				leftFileName = "nc" + domNum + "l.jpg";
			}
			else if (currentContrast == 1) {
				String domNum = String.format("%02d", number);
				leftFileName = "lc" + domNum + "l.jpg";	
			}
			else if (currentContrast == 2) {
				String domNum = String.format("%02d", number);
				leftFileName = "hc" + domNum + "l.jpg";
			}
		
			ImageIcon image = new ImageIcon(Domino.class.getResource(leftFileName));
			return image;
		}
	

	
	/*
	 * This method returns the image representing the dominos right terrain
	 * @param currentContrast, an int representing the current constrast level so the images account for it
	 */
	public ImageIcon getRightTerrainImage(int currentContrast) {
			rightFileName = "";
			if (currentContrast == 0) {
				String domNum = String.format("%02d", number);
				rightFileName = "nc" + domNum + "r.jpg";
			}
			else if (currentContrast == 1) {
				String domNum = String.format("%02d", number);
				rightFileName = "lc" + domNum + "r.jpg";	
			}
			else if (currentContrast == 2) {
				String domNum = String.format("%02d", number);
				rightFileName = "hc" + domNum + "r.jpg";
			}

	
			ImageIcon image = new ImageIcon(Domino.class.getResource(rightFileName));
			return image;
	}
	
	/*
	 * This method returns the left terrain file name for the domino
	 */
	public String getLeftTerrainFileName() {
		return leftFileName;
	}
	
	/*
	 * This method returns the right terrain file name for the domino
	 */
	public String getRightTerrainFileName() {
		return rightFileName;
	}
	
	/*
	 * This function sets the default image of the Domino - the part which has the domino number
	 */
	public void setUp() {
	
		try {
			//tileFront represents the domino number part
			
			ImageIcon tileFront = new ImageIcon(Domino.class.getResource(frontFileLocation));
		
			this.setIcon(tileFront);
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}
									
	/*
	 * This function flips a domino - changes the front image to the rear image
	 */
	public void flip() {
		
		try {
			ImageIcon tileRear = new ImageIcon(Domino.class.getResource((String)rearFileLocation));
			this.setIcon(tileRear);
			flipped = true;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * Accessor method that provides the Domino's number
	 * @return number, the domino number
	 */
	public int getDominoNumber() {
		return number;
	}
	
	/*
	 * Accessor method that helps identify if a domino is chosen or not
	 * @return !chosen, whether the domino is unchosen or not
	 */
	public Boolean isUnchosen() {
		return (!chosen);
	}
	
	/*
	 * This method sets a Domino to chosen if it was unchosen
	 * @param player, the playernumber of the player who chose this domino
	 * @param playerName, the name of the player who chose this domino
	 */
	public void chosen(int player, String playerName) {
		if (! chosen) {
			chosen = true;
			ownedBy = player;
			ownedByName = playerName;
		}
	}
	
	/*
	 * Accessor method that provides name of the player who owns this domino
	 * @return ownedByName, the name of the player who owns the domino
	 */
	public String getOwnedByName() {
		return ownedByName;
	}
	
	/*
	 * Accessor method that provides the playernumber of the player who owns this domino
	 * @return ownedBy, the number of the player who owns the domino
	 */
	public int getOwnedByNumber() {
		return ownedBy;
	}
				
	/*
	 * Accessor method that helps us identify if a domino can be placed or not
	 * @return canBePlaced, a boolean stating whether the domino can be placed or not
	 */
	public Boolean canBePlaced() {
		return canBePlaced;
	}
	
	/*
	 * This method allows a domino to be placed
	 * 
	 */
	public void allowToBePlaced() {
		canBePlaced = true;			//set to true == allow to be placed
	}
	

	/*
	 * When a domino is selected from the queues, a label is used to show which player it belongs to
	 * This method provides this functionality
	 * @param currentQueue, represents which queue the domino belongs to
	 * @param color, the player color for the player who selected the domino
	 */
	public JLabel updateLabel(int currentQueue, Color color) {
		label.setText(getOwnedByName());
		label.setForeground(color);				//label reflects the players choice of color
		label.setFont(new Font("Georgia", Font.BOLD, 20));
		
		int yPos = this.getY();
		//setting the bounds for the label based on the queue the domino is on
		if (currentQueue ==1) {
			label.setBounds(425, (yPos+415), 140,35);
		}
		else {
			label.setBounds((930), (yPos+415), 140,35);
		}
		label.setVisible(true);
		return label;
	}
	
	/*
	 * This method hides the label associated to a domino
	 * This is done when a domino is selected for placement
	 */
	public void hideLabel() {
		label.setVisible(false);
		
	}
	
	/*
	 * This method adjust the domino's label when other dominos are moved from the queues for selection
	 * @param currentQueue, the queue in which the domino belongs to
	 */
	public void moveLabelUp(int currentQueue) {
		int yPos = this.getY();
		//setting the label bounds according to the queue 
		if (currentQueue ==1) {
			label.setBounds(425, (yPos+430-80), 140,35);
		}
		else {
			label.setBounds(930, (yPos+430-80), 140,35);
		}
	}
	
	/*
	 * This method shows the left domino details, aiding color assessability
	 * @param currentQueue indicating which queue the domino belongs to
	 */
	public JLabel showLeftDominoDetails(int currentQueue) {
		int yPos = this.getY();
		if (currentQueue ==1) {
			leftTerrainLabel.setBounds(525, (yPos+410), 40,35);
		}
		else {
			leftTerrainLabel.setBounds(725, (yPos+410), 40,35);
		}
		leftTerrainLabel.setText("" + Character.toUpperCase(getLeftTerrainName().charAt(0)) + "(" +getLeftTerrainStars() +")");
		
		leftTerrainLabel.setVisible(true);
		return leftTerrainLabel;
	}
	
	/*
	 * This method shows the right half domino details, aiding color assessability
	 * @param currentQueue indicating which queue the domino belongs to
	 */
	public JLabel showRightDominoDetails(int currentQueue) {
		int yPos = this.getY();
		if (currentQueue ==1) {
			rightTerrainLabel.setBounds(680, (yPos+410), 40,35);
		}
		else {
			rightTerrainLabel.setBounds(880, (yPos+410), 40,35);
		}
		rightTerrainLabel.setText("" + Character.toUpperCase(getRightTerrainName().charAt(0)) + "(" +getRightTerrainStars() +")");
		
		rightTerrainLabel.setVisible(true);
		return rightTerrainLabel;
	}
	
	/*
	 * This method moves the left domino details up
	 * @param currentQueue indicating which queue the domino belongs to
	 */
	public void moveLeftDominoDetailsUp(int currentQueue) {
		int yPos = this.getY();
		//setting the label bounds according to the queue 
		if (currentQueue ==1) {
			leftTerrainLabel.setBounds(525, (yPos+430-80), 40,35);
		}
		else {
			leftTerrainLabel.setBounds(725, (yPos+430-80), 40,35);
		}
	}
	
	/*
	 * This method moves the right domino details up
	 * @param currentQueue indicating which queue the domino belongs to
	 */
	public void moveRightDominoDetailsUp(int currentQueue) {
		int yPos = this.getY();
		//setting the label bounds according to the queue 
		if (currentQueue ==1) {
			rightTerrainLabel.setBounds(680, (yPos+430-80), 40,35);
		}
		else {
			rightTerrainLabel.setBounds(880, (yPos+430-80), 40,35);
		}
	}
	
	/*
	 * This method shows the left domino details on the chosenDominoPanel
	 */
	public JLabel showLeftTerrainLabelOnChosenPanel() {
		
		//setting the label bounds according to the queue 
		leftTerrainLabel.setBounds(640, 260, 40,35);
		return leftTerrainLabel;	
	}
	
	/*
	 * This method shows the right  domino detaisl on the chosenDominoPanel
	 */
	public JLabel showRightTerrainLabelOnChosenPanel() {
		
		//setting the label bounds according to the queue 
		rightTerrainLabel.setBounds(775, 260, 40,35);
		return rightTerrainLabel;	
	}
	
	/*
	 * This method hides the left label on the chosen domino panel
	 */
	public void hideLeftTerrainLabelOnChosenPanel() {
		leftTerrainLabel.setVisible(false);
	}
	
	/*
	 * This method hides the right label on the chsoen domino panel
	 */
	public void hideRightTerrainLabelOnChosenPanel() {
		rightTerrainLabel.setVisible(false);
	}

	
	
	/*
	 * This method increases the contrast of the flipped dominos in the queues
	 */
	public void increaseContrast(int currentContrast) {
		String domNum = String.format("%02d", number);
			//low contrast to medium contrast
			if (currentContrast == 0) {
				rearFileLocation = "lc" + domNum + ".jpg";
			}
			//medium contrast to high contrast
			else if (currentContrast == 1) {
				rearFileLocation = "hc" + domNum + ".jpg";	
			}
			//if the domino is already flipped, then we would update the icon to reflect the change
			//else we wait for the tile to be flipped
			if (flipped) {
				ImageIcon image = new ImageIcon(Domino.class.getResource(rearFileLocation));
				this.setIcon(image);
			}
	}
	
	/*
	 * This method decreases the contrast of the flipped dominos in the queues
	 */
	public void decreaseContrast(int currentContrast) {
		
			String domNum = String.format("%02d", number);
			//medium to low contrast
			if (currentContrast == 1) {
				rearFileLocation = "nc" + domNum + ".jpg";
			}
			//high to medium contrast
			else if (currentContrast == 2) {
				rearFileLocation = "lc" + domNum + ".jpg";
			}

			//if the domino is already flipped, then we would update the icon to reflect the change
			//else we wait for the tile to be flipped
			if (flipped) {
				ImageIcon image = new ImageIcon(Domino.class.getResource(rearFileLocation));
				this.setIcon(image);
			}
	}
	
}
