import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.MatteBorder;

/*
 * The Board class represents the board where the players kingdoms are built
 * @author Mahek Parmar
 */

public class Board extends JPanel{
	Color boardColor;
	JLabel playerNameLabel;
	String playerName;
	int playerNum;
	int row = 9;			//9*9 to allow 5*5 kingdoms to be built in any orientation
	int col=9;
	protected GridBox gridsToAdd[][];
	protected Boolean blocked;				//where the board is blocked or not
	
	
	
	
	public Board(String playerName, int playerNum, Color boardColor) {
		super();
		this.playerName = playerName;
		this.boardColor = boardColor;
		this.playerNum =playerNum;
		blocked = true;				//by default every board is blocked
		getBoard();
		
	}
	

	/*
	 * This method creates a Board, taking into consideration the  color and name
	 * @return, the board for the player
	 */
	public JPanel getBoard() {
		
		JPanel topPanel = new JPanel();
		playerNameLabel = new JLabel("" + playerName +"'s Kingdom");
		playerNameLabel.setFont(new Font("Georgia", Font.BOLD, 15));
		playerNameLabel.setForeground(Color.BLACK);
		playerNameLabel.setHorizontalAlignment(JLabel.CENTER);
		playerNameLabel.setVerticalAlignment(JLabel.CENTER);
		topPanel.add(playerNameLabel);
		
		//we would the 9*9 board on the bottomPanel
		JPanel bottomPanel = new JPanel();							//creating a bottom panel
		bottomPanel.setLayout(new GridLayout(row, col));	//setting its layout to a grid layout so all the grids are equal
		
		gridsToAdd = new GridBox [row][col];				//a 2-d array that stores GridBox objects
		
		for (int i=0 ; i<row ; i++) {
			for (int j=0 ; j<col ; j ++) {
				gridsToAdd[i][j] = new GridBox(playerNum, i, j);				//adding the grids
				if (i==4 && j==4) {
					ImageIcon image = new ImageIcon(Board.class.getResource("king.jpg"));

					gridsToAdd[i][j].setCurrentFileName("king.jpg");
					gridsToAdd[i][j].setStars(0);

					gridsToAdd[i][j].setTerrain("King");
					gridsToAdd[i][j].setIcon(image);
					gridsToAdd[i][j].setNotAvailable();						//centre most grid is occupied and not availalbe by default
					gridsToAdd[i][j].makeOccupied();
				}
				if ((i==3 && j==4) || (i==5 && j==4) || (i==4 && j==3) || (i==4 && j==5)) {		//by default on the tiles tiles adjacent (top, left,bottom,right) will be avialbale
					gridsToAdd[i][j].makeAvailable(boardColor);
				}
				gridsToAdd[i][j].setBackground(Color.white);		
				bottomPanel.add(gridsToAdd[i][j]);	
			}
		}
		
		
		this.setLayout(new BorderLayout());
		this.add(topPanel, BorderLayout.NORTH);				//adding the corresponding top and bottom panels to the content pane of the frame
		this.add(bottomPanel, BorderLayout.CENTER);
		
		return this;
	}
	
	/*
	 * This method updates the name on the  board
	 * @param new_name, the new name to be presented on the board
	 */
	public void updateNameOnBoard(String new_name) {
		//NOTE : using try/catch as the method could also be called before the board is created
		try {
			//updating the name on the board's label
			playerNameLabel.setText(new_name +"'s Kingdom");
		}
		catch (Exception e){
			//do nothing
		}
	}
	
	/*
	 * This method updates the color on the board 
	 * @param color, the new color 
	 */
	public void updateColorOnBoard(Color color) {
		//again, using try/catch as the method can be called before the board is created
		try {
			boardColor = color;
			playerNameLabel.setForeground(color);		//updates color of the text on the board
			for (int i=0 ; i<row ; i++) {
				for (int j=0 ; j<col ; j ++) {				//updates color of the board grids
					gridsToAdd[i][j].setBorder(new MatteBorder(1, 1, 1, 1, color));
					gridsToAdd[i][j].setBorderPainted(true);
					if (gridsToAdd[i][j].isAvailable()) {
						gridsToAdd[i][j].setBorder(new MatteBorder(3, 3, 3, 3, color));
					}
					}
			}
		}
		catch (Exception e){
			//do nothing
		}	
	}
	
	/*
	 * This method gets alls 2-d array that stores the individual grids in the board
	 * @return gridsToAdd, the 2-d array that contains the boards individual grids
	 */
	public GridBox[][] getBoardGrids() {
		return gridsToAdd;
	}
	
	/*
	 * This accessor method lets us know if the board is blocked or not
	 * @return blocked, a boolean, true when board is blocked, else false
	 */
	public Boolean isBlocked() {
		return blocked;
	}	

	/*
	 * This method block as board
	 */
	public void block() {
		blocked = true;
	}
	
	/*
	 * This method unblocks the board
	 */
	public void unblock() {
		blocked = false;
	}
	
	/*
	 * Accessor method that gets the number of rows in the board
	 * @return row, the number of rowns in the board
	 */
	public int getRowNumber() {
		return row;
	}
	
	/*
	 * Accessor method that gets the number of columns in the board
	 * @return col, the number of columns in the board
	 */
	public int getColNumber() {
		return col;
	}
	
	
	/*
	 * This method increases the contrast on all the board grids that are occupied with a Domino
	 * @currentContrast, an int representing the contrast level
	 */
	public void increaseContrast(int currentContrast) {
		//NOTE : 
		//	currentContrast = 0, low contrast
		// 	currentContrast = 1, medium contrast
		//	currentcontrast = 2, high contrast
		
		for (int i=0; i<row ; i++) {
			for (int j=0 ; j<col ; j++) {
				
				if (gridsToAdd[i][j].isOccupied()) {				//adjust contrast only if the grid in the board is occuipied by a domino
					if (currentContrast ==1) { 
						gridsToAdd[i][j].increaseContrast(currentContrast);
					}
					if (currentContrast == 0) {
						gridsToAdd[i][j].increaseContrast(currentContrast);
					}
				}
			}
		}
	}
	
	/*
	 * This method decreases the contrast on all the board grids that are occupied with a Domino
	 * @currentContrast, an int representing the contrast level
	 */
	public void decreaseContrast(int currentContrast) {
		for (int i=0; i<row ; i++) {
			for (int j=0 ; j<col ; j++) {
				
				if (gridsToAdd[i][j].isOccupied()) {
					if (currentContrast ==1) { 
						gridsToAdd[i][j].decreaseContrast(currentContrast);						
					}
					if (currentContrast == 2) {
						gridsToAdd[i][j].decreaseContrast(currentContrast);	
					}
				}
			}
		}
	}
	
	
	/*
	 * This function checks if a row or column needs to be blocked/made out of bounds once a domino is placed
	 * We want out kingdom to be a 5*5 although the board size is 9*9
	 */
	public void boundsChecker(int r, int c) {
		GridBox[][] g = getBoardGrids();
		//Example of how it works -> if a domino half is placed just above the king, we'd block the whole bottommost row
		//as it would never be used considering a 5*5 kingdom
		if (!(r==4)) {
			int potentialBlockRow = (r<4)? r+5 : r-5;
				if (!(g[potentialBlockRow][4].isOutOfBounds())){
						blockRow(potentialBlockRow,g);
				}
		}		
		//Example of how it works -> if a domino half is placed just right the king, we'd block the first(index 0) column
		//as it would never be used considering a 5*5 kingdom
		if (!(c==4)) {
			int potentialBlockCol = (c<4)? c+5 : c-5;
			if (!(g[4][potentialBlockCol].isOutOfBounds())){
				blockCol(potentialBlockCol,g);
			}
			
		}
		
		
	}
	
	/*
	 * This function makes a whole row in the players board out of bounds
	 * @param rowToBlock, the row we want to block
	 * @param g, the 2d array of the board grids
	 */
	public void blockRow(int rowToBlock, GridBox[][]g) {
		for (int p=0 ; p<col ; p++) {			//for loop gives the index for corresponding column
		//make every position/gridbox in the row out of bounds and not available
			g[rowToBlock][p].makeOutOfBounds();
			g[rowToBlock][p].setNotAvailable();
		}
	}
	
	/*
	 * This function makes a whole column in the players board out of bounds
	 * @param colToBlock, the column we want to block
	 * @param g, the 2d array of the board grids
	 */
	public void blockCol(int colToBlock, GridBox[][]g) {
		for (int q=0 ; q<row ; q++) {				//for loop gives the index for the coorespoing row
		//make every position/gridbox in the column out of bounds and not available	
			g[q][colToBlock].makeOutOfBounds();
			g[q][colToBlock].setNotAvailable();
		}
	}
	
	/*
	 * This function removes adjacencies from the surrounding tiles once the second half of the Domino is placed
	 * to allow for smooth and correct game play
	 */
	public void removeAllAdjacencies() {
		
			GridBox [][] grids = getBoardGrids();
			for (int a=0 ; a<row ; a++) {
				for (int b=0 ; b<col ; b++) {
		//if the grid is not out of bounds, then we remove the adjacencies
					if (!(grids[a][b].isOutOfBounds())) {
						grids[a][b].setNotAdjacent();
					}
				}
			}
		
		
	}
	
	/*
	 * This method checks if the domino is validly placed or not
	 * When placing dominos atleast once half of the domino should be the same terrain as one of its neighbouring terrain or next to the king
	 * For our game, the first half of the domino must match the terrain types
	 * @param x, the x index of the selected gridbox from the players board
	 * @param y, the y index of the sleected gridbox from the players board
	 * @param terrain, a String representing the chosen domino half's terrain
	 * @return, a Boolean indiacating if its a valid placement(true) or not (false)
	 */
	public Boolean validPlacement(int x, int y, String terrain) {
		
		GridBox[][] grids = getBoardGrids();
		
		//atleast one of the neighbouring dominos terrain must match our domino half's terrain or we must place the domino half next to the king then
		try {if((grids[x-1][y].getTerrain().equals(terrain)) || (grids[x-1][y].getTerrain().equals("King"))) {
				return true;
			}
		}catch (Exception e) {}

		try {if ((grids[x][y-1].getTerrain().equals(terrain)) || (grids[x][y-1].getTerrain().equals("King"))){
				return true;
			}
		}catch (Exception e) {}

		try {if ((grids[x][y+1].getTerrain().equals(terrain)) || (grids[x][y+1].getTerrain().equals("King"))) {
				return true;
			}
		}catch (Exception e) {}
		
		try {if ((grids[x+1][y].getTerrain().equals(terrain)) || (grids[x+1][y].getTerrain().equals("King"))) {
				return true;
			}
		}
		catch (Exception e) {}
		
		//if the terrains dont match we return false
		Game.placementMessage.setText("Invalid Placement - retry or drop the Domino");
		Game.placementMessage.setForeground(boardColor);
		return false;	

	}
	
	/*
	 * This function activiates adjacent cells when half a domino is placed on the board
	 * When the first part of the domino is placed, adjacent positons must be activated (top, left, right, bottom)
	 * @param x, the x index of the individual grid on which the half domino was placed
	 * @param y, x, the y index of the individual grid on which the half domino was placed
	 * @param board, the board which was selected 
	 */
	public void adjustNeighbours(int x, int y) {
		GridBox [][] grids = getBoardGrids();
		
		//using try and catch to prevent out of bounds scenarios
				try {			
				//if the upper grid is not occupied, make it available and adjacent
					if (	!(grids[x-1][y].isOccupied()) && !(grids[x-1][y].isOutOfBounds())	) {
						grids[x-1][y].setAdjacent(boardColor);
						grids[x-1][y].makeAvailable(boardColor);
					}

				}
				catch (Exception e) {}
				try {
				//if the left grid is not occupied, make it available and adjacent
					if (	!(grids[x][y-1].isOccupied()) && !(grids[x][y-1].isOutOfBounds())	) {
						grids[x][y-1].setAdjacent(boardColor);
						grids[x][y-1].makeAvailable(boardColor);
					}
				}
				catch (Exception e) {}
				try {
				//if the right grid is not occupied, make it available and adjacent
					if (	!(grids[x+1][y].isOccupied()) && !(grids[x+1][y].isOutOfBounds())	) {
				
						grids[x+1][y].setAdjacent(boardColor);
						grids[x+1][y].makeAvailable(boardColor);
					}
				}
				catch (Exception e) {}
				try {
				//if the bottom grid is not occupied, make it available and adjacent
					if (	!(grids[x][y+1].isOccupied()) && !(grids[x][y+1].isOutOfBounds())	) {
				
						grids[x][y+1].setAdjacent(boardColor);
						grids[x][y+1].makeAvailable(boardColor);
					}
				}
				catch (Exception e) {}	
						
	}

	/*
	 * This function checks if there are neighbouring available adjacent positions given a starting position
	 * @param x, an int representingt the x index
	 * @param y, an int representing the y index 
	 */
	public Boolean hasAdjacentPosition(int x, int y) {
		GridBox [][] grids = getBoardGrids();
		
		try {if(!grids[x-1][y].isOccupied() && !grids[x-1][y].isOutOfBounds()) {
				return true;
		}}
		catch (Exception e) {}
		
		try {if(!grids[x][y-1].isOccupied() && !grids[x][y-1].isOutOfBounds()) {
				return true;
		}}
		catch (Exception e) {}
		
		try {if(!grids[x+1][y].isOccupied() && !grids[x+1][y].isOutOfBounds()) {
				return true;
		}}
		catch (Exception e) {}

		try {if(!grids[x][y+1].isOccupied() && !grids[x][y+1].isOutOfBounds()) {
				return true;
		}}
		catch (Exception e) {}
		//that chosen grid has no adjacent position which is avaialbel
		Game.placementMessage.setText("Not enough space - retry or drop the Domino!");
		Game.placementMessage.setFont(new Font("Georgia", Font.BOLD, 20));
		Game.placementMessage.setForeground(boardColor);
		
		grids[x][y].setNotAvailable();			//that grid is no longer available!
		return false;
	}
	
	/*
	 * This method converts the Board to reflect the Raw mode
	 */
	public void changeToRawMode() {
		GridBox[][] grids = getBoardGrids();
		
		for (int i=0 ; i<row ; i++) {
			for (int j=0 ; j<col ; j++) {
				grids[i][j].changeToRawMode();
			}
		}
	}
	
	/*
	 * This method removes the Raw mode from a Board
	 */
	public void exitRawMode() {
		GridBox[][] grids = getBoardGrids();
		
		for (int i=0 ; i<row ; i++) {
			for (int j=0 ; j<col ; j++) {
				if (grids[i][j].isOccupied()) {
					grids[i][j].exitRawMode();
				}
			}
		}
	}
	
}