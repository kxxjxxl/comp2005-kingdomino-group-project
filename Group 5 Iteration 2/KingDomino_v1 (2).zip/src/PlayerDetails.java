import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.*;
import java.util.*;


/*
 * This class gathers the player details, such as their name and chosen color pallet using the GUI
 * @author Mahek Parmar
 */
public class PlayerDetails {
	JFrame frame;
	ArrayList<Player> playerList;
	
	public PlayerDetails(ArrayList<Player> playerList, JFrame frame) {
		this.frame = frame;
		this.playerList = playerList;
		addDetails(playerList);			//internal method call
	}

	/*
	 * This method does the actual work of presenting and collecting player info using the GUI
	 * @param playerList, the player list containing all our Player
	 * 
	 */
	public void addDetails(ArrayList<Player> playerList) {
		
		for (int i=0 ; i < playerList.size() ; i++) {
			Player currentPlayer= playerList.get(i);
			
			//get the color pallet from the Player
			JPanel colorPallet = currentPlayer.getColorPallet();
			
			//displaying the player name
			JPanel playerHeading = new JPanel();
			JLabel playerNameLabel = new JLabel(currentPlayer.getPlayerName()); 
			playerNameLabel.setFont(new Font("Georgia", Font.PLAIN, 25));
			playerNameLabel.setVerticalAlignment(JLabel.CENTER);
			playerNameLabel.setHorizontalAlignment(JLabel.CENTER);
			playerHeading.add(playerNameLabel);
			 
			//code for making it possible to edit the player name via a button			
			JButton editNameButton = new JButton ("Tap To Edit Name");
			editNameButton.addActionListener(e -> editName(currentPlayer, playerNameLabel));
			JPanel buttonHolder = new JPanel();
			buttonHolder.add(editNameButton);
			
			//arranging everything together in the GUI, based on the player ID (aka player numbers)
			if (currentPlayer.getPlayerID() == 1) {
				playerHeading.setBounds(90,5,100,40);
				buttonHolder.setBounds(50,60,180,40);
				colorPallet .setBounds(50,120,180,50);
			}
			else if (currentPlayer.getPlayerID() == 3 ) {
				playerHeading.setBounds(90,250,100,40);
				buttonHolder.setBounds(50,305,180,40);
				colorPallet.setBounds(50,350,180,50);
			}
			else if (currentPlayer.getPlayerID() == 2) {
				playerHeading.setBounds(380,5,100,40);
				buttonHolder.setBounds(340,60,180,40);
				colorPallet.setBounds(340,120,180,50);
			}
			else {
				playerHeading.setBounds(380,250,100,40);
				buttonHolder.setBounds(340,305,180,40);
				colorPallet.setBounds(340,350,180,50);
			
			}
			frame.add(buttonHolder);
			frame.add(playerHeading);
			frame.add(colorPallet);
			
		}	
		
}
	/*
	 * This method request and updates the player name when the user selects to edit it
	 * @param player, the Player object whose name is to be changed
	 * @param label, the JLabel displaying the playername on the GUI
	 */
	public void editName(Player player, JLabel label) {	
		//get the new name
		String newName = JOptionPane.showInputDialog("Please enter name for Player-" + player.getPlayerID());
		//updating it for the Player object and for the JLabel on the GUI
		if (! (newName == null)) {
			if (!newName.isEmpty()) {
				player.updatePlayerName(newName);
				label.setText(player.getPlayerName());
			}
		}
	}	
}


