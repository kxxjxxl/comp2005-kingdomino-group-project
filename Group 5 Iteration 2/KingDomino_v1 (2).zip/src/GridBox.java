import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

/*
* The GridBox class involves the grids/boxes which are the base of the whole game together with their interactive behaviors 
* NOTE: this class is used as it will help us for future functionalities, more implementation will be added to this class in the future
* @author  Mahek Bharat Parmar

*/

public class GridBox extends JButton {
	
	int status;		//status of a particular grid (0 if available / unoccupied, 1 if occupied by player 1, and 2 if occupied by player 2)
	
	public GridBox() {
		super();

	}
}