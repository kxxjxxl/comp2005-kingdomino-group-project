import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;

/*
 * The Player class represents the actual player and its various attributes
 * @author Mahek Parmar
 */
public class Player{
	protected int playerID;
	protected String playerType;
	protected Color playerColor;
	protected String playerName;
	JLabel playerNameLabel;
	JPanel playerBoard;
	
	//represent the row and column choice for the board
	protected int row = 5;
	protected int col = 5;
	
	private ArrayList<JButton> buttonList = new ArrayList<>();;
	protected GridBox gridsToAdd[][];

	public Player(int id) {
		playerID = id;
		playerName = "Player " + id;			//by default the player name would be Player followed by its number, for eg => Player 1
	}
	
	/*
	 * Accessor method to get the playerID
	 * @return playerID, the players ID
	 */
	protected int getPlayerID() {
		return playerID;
	}

	/*
	 * Accessor method to get the playerType
	 * @return playerType, the type of the player (human or AI) 
	 */
	protected String getType() {
		return playerType;
	}
	
	/*
	 * Accessor method to get the player's Color
	 * @return playerColor, the players Color
	 */
	protected Color getColor() {
		return playerColor;
	}

	/*
	 * Accessor method to get the player's name
	 * @return playerName, the players name
	 */
	protected String getPlayerName() {
		return playerName;
	}

	/*
	 * Mutator method to update the players color
	 * @param color, the color to update
	 */
	protected void updatePlayerColor(Color color) {
		playerColor = color;
	}
	

	/*
	 * Mutator method to update the players name
	 * @param newName, the name to be updated
	 */
	public void updatePlayerName(String newName) {
		playerName = newName;
		updateNameOnBoard(newName);		//makes an internal method call to update the name on the board too
		
	}

	/*
	 * This method creates a color pallet for the players
	 * @return colorPallet, the color pallet
	 */
	protected JPanel getColorPallet() {
		
		JPanel colorPallet = new JPanel();
		colorPallet.setLayout(new GridLayout(2,1));
		colorPallet.add(getRegularColorPallet());				//regular color pallet that contains regular normal colors
		colorPallet.add(getProtanopiaColorPallet());			//protanopia color pallet that contains colors that aid ppl with protanopia (main type of color deficiency)
		return colorPallet;
	}
	
	/*
	 * This method helps create the regular color pallet
	 * @return regularColorPallet, the color pallet containing all the regular colors
	 */
	protected JPanel getRegularColorPallet() {
		// NOTE: every color in the pallet is implemented as a button allowing the user the select it
		//       Upon selection this updates the playerColor and also the board and labels related to that particular player
		//       aiding their color vision
		
		JButton redButton = new JButton();
		redButton.setBackground(Color.RED);
		redButton.addActionListener(e-> setToRed(redButton));
		
		JButton greenButton = new JButton();
		greenButton.setBackground(Color.GREEN);
		greenButton.addActionListener(e-> setToGreen(greenButton));
		
		JButton yellowButton = new JButton();
		yellowButton.setBackground(Color.YELLOW);
		yellowButton.addActionListener(e-> setToYellow(yellowButton));
		
		JButton blueButton = new JButton();
		blueButton.setBackground(Color.BLUE);
		blueButton.addActionListener(e-> setToBlue(blueButton));
		
		//this buttonList arrayList contains all the color pallet buttons, so that we can only allow 1 color to be selected at once
		
		buttonList.add(redButton);
		buttonList.add(blueButton);
		buttonList.add(yellowButton);
		buttonList.add(greenButton);
		
		JPanel regularColorPallet = new JPanel();
		regularColorPallet.setLayout(new GridLayout(1,4));

		regularColorPallet.add(redButton);
		regularColorPallet.add(greenButton);
		regularColorPallet.add(blueButton);
		regularColorPallet.add(yellowButton);
		
		return regularColorPallet;
	}
	
	/*
	 * This method helps create the protanopia color pallet aiding people with protanopia color difficiency
	 * @return protanopiaColorPallet, the color pallet containing all the protanopis colors
	 */
	
	protected JPanel getProtanopiaColorPallet() {
		//NOTE; here we are using custom customs created based on RGB composition, this choice was made based on research on protanopia colors
		//      Again every color is implemented as a button that updates the playerColor and reflects the change on the players board and labels
		
		JButton softYellowButton = new JButton();
		softYellowButton.setBackground(new Color(250,240,100));
		softYellowButton.addActionListener(e-> setToSoftYellow(softYellowButton));
		
		JButton darkBlueButton = new JButton();
		darkBlueButton.setBackground(new Color(49,60,147));
		darkBlueButton.addActionListener(e-> setToDarkBlue(darkBlueButton));
		
		JButton greyBlueButton = new JButton();
		greyBlueButton.setBackground(new Color(102,153,204));
		greyBlueButton.addActionListener(e-> setToGreyBlue(greyBlueButton));
		
		JButton moderateYellowButton = new JButton();
		moderateYellowButton.setBackground(new Color(180,170,60));
		moderateYellowButton.addActionListener(e-> setToModerateYellow(moderateYellowButton));
		
	
		buttonList.add(softYellowButton);
		buttonList.add(darkBlueButton);
		buttonList.add(greyBlueButton);
		buttonList.add(moderateYellowButton);
		
		
		JPanel protanopiaColorPallet = new JPanel();
		protanopiaColorPallet.setLayout(new GridLayout(1,4));

		protanopiaColorPallet.add(softYellowButton);
		protanopiaColorPallet.add(darkBlueButton);
		protanopiaColorPallet.add(greyBlueButton);
		protanopiaColorPallet.add(moderateYellowButton);
		
		return protanopiaColorPallet;
	}
	

	/*
	 * This method updates the player's color when the player selects the red color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToRed(JButton button) {
		removeOthersBorder(button);		//internal method call to a method that removes the selection border from all the other colors
		updatePlayerColor(Color.RED);
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));			//visually helps us see which color was selected
		button.setBorderPainted(true);
		updateColorOnBoard(Color.RED);			//internal method call that updates the color on the players board and label too		
	}
	
	/*
	 * This method updates the player's color when the player selects the blue color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToBlue(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(Color.BLUE);
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		updateColorOnBoard(Color.BLUE);
	}
	
	/*
	 * This method updates the player's color when the player selects the green color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToGreen(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(Color.GREEN);
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		updateColorOnBoard(Color.GREEN);
	}
	
	/*
	 * This method updates the player's color when the player selects the yellow color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToYellow(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(Color.YELLOW);
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		updateColorOnBoard(Color.YELLOW);
	}
	
	/*
	 * This method updates the player's color when the player selects the soft yellow color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */	
	protected void setToSoftYellow(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(new Color(250,240,100));
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		updateColorOnBoard(new Color(250,240,100));
	}
	
	/*
	 * This method updates the player's color when the player selects the dark blue color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToDarkBlue(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(new Color(49,60,147));
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		updateColorOnBoard(new Color(49,60,147));
	}
	
	/*
	 * This method updates the player's color when the player selects the frey blue color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToGreyBlue(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(new Color(102,153,204));
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		updateColorOnBoard(new Color(102,153,204));
	}
	
	/*
	 * This method updates the player's color when the player selects the  moderate yellow color from the color pallet
	 * @param button, the JButton that the player selects
	 * 
	 */
	protected void setToModerateYellow(JButton button) {
		removeOthersBorder(button);
		updatePlayerColor(new Color(180,170,60));
		button.setBorder(new MatteBorder(2, 2, 2, 2, Color.BLACK));
		button.setBorderPainted(true);
		updateColorOnBoard(new Color(180,170,60));
	}
	
	/*
	 * This method removes the selection border from all the colors except from the currently chosen color
	 * @param button, the JButton representing a color that the player chose
	 */
	protected void removeOthersBorder(JButton button) {
		//give an empty border for all other colors in the pallet except for this chosen color
		for (int i=0 ; i<buttonList.size() ; i++) {
			if (buttonList.get(i) != button) {
				buttonList.get(i).setBorder(new EmptyBorder(2,2,2,2));
			}
		}
		
	}

	
	/*
	 * This method creates the Board for every player, taking into consideration their chosen view color and name
	 * @JPanel playerBoard, the board for the player
	 */
	protected JPanel getPlayerBoard() {
		//topPanel contains details of the players name
		JPanel topPanel = new JPanel();
		playerNameLabel = new JLabel("" + getPlayerName() +"'s Kingdom");
		playerNameLabel.setFont(new Font("Georgia", Font.BOLD, 15));
		playerNameLabel.setForeground(getColor());
		playerNameLabel.setHorizontalAlignment(JLabel.CENTER);
		playerNameLabel.setVerticalAlignment(JLabel.CENTER);
		topPanel.add(playerNameLabel);
		
		//we would the 5*5 board on the bottomPanel
		JPanel bottomPanel = new JPanel();							//creating a bottom panel
		bottomPanel.setLayout(new GridLayout(row, col));	//setting its layout to a grid layout so all the grids are equal
		
		gridsToAdd = new GridBox [row][col];				//a 2-d array that stores GridBox objects
		
		for (int i=0 ; i<row ; i++) {
			for (int j=0 ; j<col ; j ++) {
				gridsToAdd[i][j] = new GridBox();				//adding the grids
				gridsToAdd[i][j].setBackground(getColor());		//the grid colors reflect the players chosen color for viewing
				bottomPanel.add(gridsToAdd[i][j]);	
			}
		}
		
		JPanel playerBoard = new JPanel();
		playerBoard.setLayout(new BorderLayout());
		playerBoard.add(topPanel, BorderLayout.NORTH);				//adding the corresponding top and bottom panels to the content pane of the frame
		playerBoard.add(bottomPanel, BorderLayout.CENTER);
		
		return playerBoard;
	}
	
	/*
	 * This method updates the player name on the players board
	 * @param new_name, the new name for the player
	 */
	public void updateNameOnBoard(String new_name) {
		//NOTE : using try/catch as the method could also be called before the board is created
		try {
			//updating the name on the board's label
			playerNameLabel.setText(new_name +"'s Kingdom");
		}
		catch (Exception e){
			//do nothing
		}
	}
	
	/*
	 * This method updates the color on a players board 
	 * @param color, the color chosen by the player
	 */
	public void updateColorOnBoard(Color color) {
		//again, using try/catch as the method can be called before the board is created
		try {
			playerNameLabel.setForeground(color);		//updates color of the text on the board
			for (int i=0 ; i<row ; i++) {
				for (int j=0 ; j<col ; j ++) {				//updates color of the board grids
					gridsToAdd[i][j].setBackground(color);
					}
			}
		}
		catch (Exception e){
			//do nothing
		}
		
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
