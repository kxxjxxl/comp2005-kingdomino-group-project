import java.awt.*;
import javax.swing.*;
import java.util.*;

/*
 * This class allows us to collect player related information for each player
 * Information such as player name, players chosen color and so on.
 * @author Mahek Parmar
 */

public class SetUpPlayers {
	
	protected static JFrame frame;
	protected static Container contentPane;
	private ArrayList<Player> playerList;			//this arraylist stores the Player objects playing the game
	
	
	//private JLabel playerName;
	
	public SetUpPlayers(int noOfPlayers) {
		playerList = new ArrayList<>();
		//building and organizing the frame
		frame = new JFrame("Player Settings");
		contentPane = frame.getContentPane();
		contentPane.setLayout(null);
		frame.setPreferredSize(new Dimension(600,500));
		setUp(noOfPlayers);
		//housekeeping code
		frame.setVisible(true);
		frame.setResizable(false);
		frame.pack();
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
		
	}
	
	/*
	 * Based on how many players want to play the game, this method instantiates that number of players and stores them to our playerList arraylist
	 * @param noOfPlayers, the number of players who are playing the game
	 */
	private void setUp(int noOfPlayers) {
		for (int i = 1 ; i<=noOfPlayers ; i++) {
			playerList.add(new Player(i));
		}
		addDetails();			//internal method call
	}
	
	/*
	 * This method gathers the player information from the user input
	 */
	public void addDetails() {
		//calls a helper class that helps us collect information about a player
		PlayerDetails displayDetails = new PlayerDetails(playerList, frame);
			
		//code for the next step image
		ImageIcon nextImage = new ImageIcon("next.jpg");
		JButton nextButton = new JButton(nextImage);
		nextButton.addActionListener(e -> startGame());			//when the next button is clicked, after getting all player info, then we start the actual game
		JPanel nextPanel = new JPanel();
		nextPanel.add(nextButton);
		nextPanel.setBounds(530,400,50,60);
		frame.add(nextPanel);
		
	}
		
		
	/*
	 * This method initiates the game
	 */
	public void startGame() {
		frame.dispose();
		GameUI board = new GameUI(playerList);
		
	}	

}
