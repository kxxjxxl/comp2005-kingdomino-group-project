import java.awt.*;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.*;

/* 
 * The driver class which initiates the game 
 * @author Mahek Parmar
 */

public class HomeScreen {
	
	private static JFrame frame;
	private static Container contentPane;
	public static void main(String [] args) {

		frame = new JFrame("KingDomino");
		contentPane = frame.getContentPane();
		contentPane.setLayout(null);
		frame.setPreferredSize(new Dimension(1100,850));
		
		
		setUp();
		
		
		//housekeeping code
		frame.pack();
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);

	}
	
	/*
	 * This method set's up the home screen to give its appearance with the load and save game buttons
	 * 
	 */
	public static void setUp() {
		ImageIcon image = new ImageIcon("image.jpg");		//using the kingdomino image
		JLabel icon = new JLabel(image);
		JPanel iconPanel = new JPanel();
		iconPanel.setBounds(0,0,1100,500);
		iconPanel.add(icon);
		
		
		//gamename and short mssg
		JPanel gameNamePanel = new JPanel();
		JLabel gameNameLabel = new JLabel("KingDomino");
		gameNameLabel.setFont(new Font("Georgia", Font.PLAIN, 100));
		gameNameLabel.setVerticalAlignment(JLabel.CENTER);
		gameNameLabel.setHorizontalAlignment(JLabel.CENTER);
		
		gameNamePanel.add(gameNameLabel);
		gameNamePanel.setBounds(60,500,1000,150);
		contentPane.add(gameNamePanel);
		
		
		JPanel funMssgPanel = new JPanel();
		JLabel funMssgLabel= new JLabel("Lets have fun!!!");
		funMssgLabel.setFont(new Font("Georgia", Font.PLAIN, 50));
		funMssgLabel.setVerticalAlignment(JLabel.CENTER);
		funMssgLabel.setHorizontalAlignment(JLabel.CENTER);
		
		funMssgPanel.add(funMssgLabel);
		funMssgPanel.setBounds(60,650,1000,100);
		contentPane.add(funMssgPanel);
		
		//new game button
		JPanel buttonPanel = new JPanel();
		JButton newGame = new JButton("New Game");
		newGame.addActionListener(e -> playNewGame());			//setting its action listener
		
		
		JButton loadGame = new JButton("Load Game");
		loadGame.addActionListener(e -> loadGame());		//this functionality will come in later methods
		
		//putting everything together
		buttonPanel.add(newGame);
		buttonPanel.add(loadGame);
		buttonPanel.setBounds(0,750, 1100,50);
		contentPane.add(buttonPanel);
		
		contentPane.add(iconPanel);
		
	}
	
	
	/*
	 * This method initiates a new game
	 * 
	 */
	private static void playNewGame() {
		frame.dispose();			//close the current frame
		SetUpMenu setup = new SetUpMenu();			//call the SetUpMenu
		
	}
	
	/*
	 * This method provides the functionality for loading a game
	 * 
	 */
	private static void loadGame() {
		JOptionPane.showMessageDialog(frame, "Functionality coming soon!" , "Load Game", JOptionPane.INFORMATION_MESSAGE);
	}
}
